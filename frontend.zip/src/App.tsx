import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import Login from './pages/Login';
import Products from './pages/Products';
import CRM from './pages/CRM';
import Agents from './pages/Agents';
import Connections from './pages/Connections';
import Intelligence from './pages/Intelligence';
import Layout from './components/Layout';
import api from './services/api';

// Dashboard "Vivo" - Conectado à Realidade
function DashboardHome() {
  const [metrics, setMetrics] = useState({
    totalLeads: 0,
    totalSales: 0,
    conversionRate: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchMetrics();
  }, []);

  const fetchMetrics = async () => {
    try {
      // Buscamos TODOS os leads (sem filtro de pipeline para pegar o geral)
      // Nota: Idealmente, teríamos uma rota /api/dashboard/stats no backend para performance
      const response = await api.get('/crm/board'); 
      const leads = response.data;

      const total = leads.length;
      
      // Cálculo de Vendas: Soma o valor onde o status é 'won' (Ganho)
      // Ajuste 'won' para o nome da coluna que você usa para venda fechada
      const sales = leads
        .filter((l: any) => l.status === 'won' || l.status === 'venda_realizada') 
        .reduce((acc: number, curr: any) => acc + Number(curr.value || 0), 0);

      // Conversão: Leads ganhos / Total
      const winners = leads.filter((l: any) => l.status === 'won' || l.status === 'venda_realizada').length;
      const conversion = total > 0 ? ((winners / total) * 100).toFixed(1) : 0;

      setMetrics({
        totalLeads: total,
        totalSales: sales,
        conversionRate: Number(conversion)
      });
    } catch (error) {
      console.error("Erro ao carregar dashboard", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout title="Visão Geral do Império">
       <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
         {/* Card Leads */}
         <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-lg animate-fade-in-up">
           <h3 className="text-slate-400 text-sm font-medium">Leads Totais</h3>
           <p className="text-3xl font-bold text-white mt-2">
             {loading ? '...' : metrics.totalLeads}
           </p>
         </div>

         {/* Card Vendas */}
         <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-lg animate-fade-in-up delay-100">
           <h3 className="text-slate-400 text-sm font-medium">Vendas Confirmadas</h3>
           <p className="text-3xl font-bold text-emerald-400 mt-2">
             {loading ? '...' : new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(metrics.totalSales)}
           </p>
         </div>

         {/* Card Conversão */}
         <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-lg animate-fade-in-up delay-200">
           <h3 className="text-slate-400 text-sm font-medium">Taxa de Conversão</h3>
           <p className="text-3xl font-bold text-purple-400 mt-2">
             {loading ? '...' : `${metrics.conversionRate}%`}
           </p>
         </div>
       </div>

       {/* Área para Gráficos Futuros */}
       <div className="bg-slate-900 p-8 rounded-2xl border border-slate-800 text-center text-slate-500">
          <p>Gráficos de performance semanal carregando em breve...</p>
       </div>
    </Layout>
  );
}

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login />} />
        
        {/* === ROTAS DO SISTEMA === */}
        <Route path="/dashboard" element={<DashboardHome />} />
        <Route path="/crm" element={<CRM />} />
        <Route path="/products" element={<Products />} />
        
        {/* Rotas Avançadas */}
        <Route path="/agents" element={<Agents />} />
        <Route path="/intelligence" element={<Intelligence />} />
        <Route path="/connections" element={<Connections />} />

        {/* Placeholder para Agenda */}
        <Route path="/agenda" element={<Layout title="Agenda"><p className="text-slate-500">Agenda integrada em breve...</p></Layout>} />

        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App
