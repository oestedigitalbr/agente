import { useEffect, useState } from 'react';
import Layout from '../components/Layout';
import api from '../services/api';
import { 
    Calendar, CheckCircle, Clock, Search, ArrowRight, CheckSquare, 
    Filter, AlertCircle, MessageSquare 
} from 'lucide-react';
import LeadDetailsModal from '../components/LeadDetailsModal';

interface AgendaItem {
    id: string;
    type: 'appointment' | 'follow_up';
    title: string;
    description: string;
    date: string;
    lead_id?: string;
    status: string;
}

export default function Agenda() {
    const [items, setItems] = useState<AgendaItem[]>([]);
    const [loading, setLoading] = useState(true);
    
    // Para abrir o modal do lead se clicar no item
    const [selectedLeadId, setSelectedLeadId] = useState<string | null>(null);
    const [leadModalData, setLeadModalData] = useState<any>(null);

    async function loadAgenda() {
        setLoading(true);
        try {
            const res = await api.get('/api/agenda');
            setItems(res.data);
        } catch (error) {
            console.error("Erro ao carregar agenda", error);
        } finally {
            setLoading(false);
        }
    }

    useEffect(() => { loadAgenda(); }, []);

    // AÇÃO DE CONFIRMAR / CONCLUIR
    async function handleComplete(item: AgendaItem) {
        // Efeito otimista: remove da tela na hora
        setItems(items.filter(i => !(i.id === item.id && i.type === item.type)));

        try {
            if (item.type === 'appointment') {
                // Marca reunião como concluída
                await api.put(`/api/agenda/${item.id}`, { status: 'completed' });
            } else {
                // Limpa o Follow-up do Lead
                await api.put(`/api/crm/leads/${item.id}`, { 
                    follow_up_date: null, 
                    follow_up_notes: null 
                });
            }
        } catch (error) {
            alert('Erro ao concluir tarefa. Tente novamente.');
            loadAgenda(); // Reverte se der erro
        }
    }

    // Abre o modal do lead (opcional, se quiser ver detalhes)
    async function openLeadDetails(leadId?: string) {
        if (!leadId) return;
        try {
            // WORKAROUND: Busca no board all para pegar dados completos do lead
            const res = await api.get('/api/crm/board?pipeline=all');
            const found = res.data.find((l: any) => l.id === leadId);
            if (found) {
                setLeadModalData(found);
                setSelectedLeadId(leadId);
            }
        } catch (error) { console.error(error); }
    }

    // Agrupamento por data (Hoje, Amanhã, Futuro)
    function getGroup(dateStr: string) {
        const d = new Date(dateStr);
        const today = new Date();
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);

        if (d.toDateString() === today.toDateString()) return 'Hoje';
        if (d.toDateString() === tomorrow.toDateString()) return 'Amanhã';
        if (d < today) return 'Atrasados';
        return 'Futuro';
    }

    const groupedItems = items.reduce((acc, item) => {
        const group = getGroup(item.date);
        if (!acc[group]) acc[group] = [];
        acc[group].push(item);
        return acc;
    }, {} as Record<string, AgendaItem[]>);

    const groupOrder = ['Atrasados', 'Hoje', 'Amanhã', 'Futuro'];

    return (
        <Layout title="Agenda & Tarefas">
            <div className="flex flex-col h-full overflow-hidden">
                
                {/* HEADER SIMPLES */}
                <div className="flex justify-between items-center mb-6 shrink-0">
                    <p className="text-slate-400">Gerencie suas reuniões e follow-ups em um só lugar.</p>
                    <button onClick={loadAgenda} className="text-sm text-blue-400 hover:text-white transition">
                        Atualizar Lista
                    </button>
                </div>

                {/* CONTEÚDO SCROLLÁVEL */}
                <div className="flex-1 overflow-y-auto space-y-8 pr-2">
                    {loading ? (
                        <div className="text-center py-20 text-slate-500 animate-pulse">Carregando sua agenda...</div>
                    ) : items.length === 0 ? (
                        <div className="text-center py-20 border border-dashed border-slate-800 rounded-2xl bg-slate-900/50">
                            <CheckCircle size={64} className="mx-auto text-emerald-500 mb-4 opacity-50"/>
                            <h3 className="text-xl font-bold text-white">Tudo limpo!</h3>
                            <p className="text-slate-500">Você não tem tarefas pendentes.</p>
                        </div>
                    ) : (
                        groupOrder.map(group => groupedItems[group] && (
                            <div key={group} className="animate-fade-in-up">
                                <h3 className={`font-bold text-sm uppercase tracking-wider mb-3 flex items-center gap-2 
                                    ${group === 'Atrasados' ? 'text-red-400' : group === 'Hoje' ? 'text-emerald-400' : 'text-slate-400'}`}>
                                    {group === 'Atrasados' && <AlertCircle size={16}/>}
                                    {group === 'Hoje' && <Calendar size={16}/>}
                                    {group}
                                </h3>
                                
                                <div className="space-y-3">
                                    {groupedItems[group].map(item => (
                                        <div key={`${item.type}-${item.id}`} className="bg-slate-950 border border-slate-800 p-4 rounded-xl flex items-center justify-between group hover:border-blue-500/50 transition shadow-sm">
                                            
                                            {/* ESQUERDA: Ícone e Infos */}
                                            <div className="flex items-center gap-4 flex-1 cursor-pointer" onClick={() => openLeadDetails(item.lead_id)}>
                                                <div className={`p-3 rounded-full shrink-0 ${item.type === 'appointment' ? 'bg-purple-500/10 text-purple-400' : 'bg-orange-500/10 text-orange-400'}`}>
                                                    {item.type === 'appointment' ? <Calendar size={20}/> : <Clock size={20}/>}
                                                </div>
                                                <div>
                                                    <h4 className="font-bold text-white text-base group-hover:text-blue-400 transition">{item.title}</h4>
                                                    <div className="flex items-center gap-3 text-sm text-slate-500 mt-1">
                                                        <span className="flex items-center gap-1">
                                                            <Clock size={12}/> 
                                                            {new Date(item.date).toLocaleTimeString('pt-BR', {hour: '2-digit', minute:'2-digit'})}
                                                            {group !== 'Hoje' && ` - ${new Date(item.date).toLocaleDateString('pt-BR')}`}
                                                        </span>
                                                        {item.description && (
                                                            <span className="flex items-center gap-1 max-w-xs truncate" title={item.description}>
                                                                • <MessageSquare size={12}/> {item.description}
                                                            </span>
                                                        )}
                                                    </div>
                                                </div>
                                            </div>

                                            {/* DIREITA: Ação de Concluir */}
                                            <button 
                                                onClick={() => handleComplete(item)}
                                                className="ml-4 flex items-center gap-2 px-4 py-2 bg-slate-900 border border-slate-700 rounded-lg text-slate-300 hover:bg-emerald-600 hover:text-white hover:border-emerald-500 transition group/btn"
                                                title="Marcar como Concluído"
                                            >
                                                <span className="text-xs font-bold uppercase hidden md:block">Concluir</span>
                                                <CheckSquare size={18} className="group-hover/btn:scale-110 transition-transform"/>
                                            </button>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        ))
                    )}
                </div>

                {/* MODAL DETALHES (Se clicar no item) */}
                {leadModalData && (
                    <LeadDetailsModal 
                        isOpen={!!leadModalData} 
                        onClose={() => setLeadModalData(null)} 
                        lead={leadModalData}
                        onUpdate={() => { loadAgenda(); setLeadModalData(null); }}
                    />
                )}
            </div>
        </Layout>
    );
}