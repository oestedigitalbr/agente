import { useEffect, useState } from 'react';
import Layout from '../components/Layout';
import api from '../services/api';
import { 
    Brain, Plus, Trash2, FileText, X, Save, Loader2, List, Type, 
    AlignLeft, CheckSquare, ChevronDown, Edit
} from 'lucide-react';

type QuestionType = 'short_text' | 'long_text' | 'select' | 'radio';

interface QuestionConfig {
  id: string; 
  text: string;
  type: QuestionType;
  options: string[]; 
}

interface KnowledgeBase {
  id: string;
  name: string;
  questions: QuestionConfig[];
}

export default function Intelligence() {
  const [bases, setBases] = useState<KnowledgeBase[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Controle do Modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null); // ID se estiver editando

  // Form Data
  const [formName, setFormName] = useState('');
  const [questions, setQuestions] = useState<QuestionConfig[]>([]);
  const [isSaving, setIsSaving] = useState(false);

  // --- LEITURA (READ) ---
  async function loadBases() {
    setLoading(true);
    try {
      const response = await api.get('/api/knowledge-bases');
      const formattedData = response.data.map((b: any) => ({
          ...b,
          questions: typeof b.questions[0] === 'string' 
            ? b.questions.map((q: string) => ({ id: Math.random().toString(), text: q, type: 'long_text', options: [] })) 
            : b.questions
      }));
      setBases(formattedData);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadBases(); }, []);

  // --- AÇÕES DE CRUD ---

  // 1. ABRIR PARA CRIAR
  function handleOpenCreate() {
      setEditingId(null);
      setFormName('');
      setQuestions([{ id: Math.random().toString(), text: '', type: 'long_text', options: [] }]);
      setIsModalOpen(true);
  }

  // 2. ABRIR PARA EDITAR
  function handleOpenEdit(base: KnowledgeBase) {
      setEditingId(base.id);
      setFormName(base.name);
      // Garante IDs únicos para o React nas perguntas
      const editableQuestions = base.questions.map(q => ({
          ...q,
          id: q.id || Math.random().toString() // Garante ID se vier do banco sem
      }));
      setQuestions(editableQuestions);
      setIsModalOpen(true);
  }

  // 3. EXCLUIR
  async function handleDelete(id: string) {
      if(!confirm('Tem certeza que deseja excluir este formulário?')) return;
      try {
          await api.delete(`/api/knowledge-bases/${id}`);
          setBases(bases.filter(b => b.id !== id));
      } catch (error) {
          alert('Erro ao excluir.');
      }
  }

  // 4. SALVAR (CREATE ou UPDATE)
  async function handleSave() {
    if (!formName) return alert('Dê um nome ao formulário!');
    const validQuestions = questions.filter(q => q.text.trim() !== '');
    if (validQuestions.length === 0) return alert('Adicione perguntas!');

    setIsSaving(true);
    try {
      const payload = {
        name: formName,
        questions: validQuestions
      };

      if (editingId) {
          // UPDATE
          await api.put(`/api/knowledge-bases/${editingId}`, payload);
          alert('Formulário atualizado!');
      } else {
          // CREATE
          await api.post('/api/knowledge-bases', payload);
          alert('Formulário criado!');
      }

      setIsModalOpen(false);
      loadBases();
    } catch (error) {
      console.error(error);
      alert('Erro ao salvar. Verifique o console.');
    } finally {
      setIsSaving(false);
    }
  }

  // --- MANIPULAÇÃO DAS PERGUNTAS ---
  function addQuestion() {
    setQuestions([...questions, { id: Math.random().toString(), text: '', type: 'long_text', options: [] }]);
  }
  function removeQuestion(id: string) {
    setQuestions(questions.filter(q => q.id !== id));
  }
  function updateQuestion(id: string, field: keyof QuestionConfig, value: any) {
    setQuestions(questions.map(q => q.id === id ? { ...q, [field]: value } : q));
  }
  function addOption(qId: string, optionText: string) {
      if(!optionText.trim()) return;
      const question = questions.find(q => q.id === qId);
      if(question) {
          updateQuestion(qId, 'options', [...question.options, optionText]);
      }
  }
  function removeOption(qId: string, optionIndex: number) {
      const question = questions.find(q => q.id === qId);
      if(question) {
          const newOptions = question.options.filter((_, i) => i !== optionIndex);
          updateQuestion(qId, 'options', newOptions);
      }
  }

  // Ícones
  const typeIcons = {
      short_text: <Type size={14}/>,
      long_text: <AlignLeft size={14}/>,
      select: <List size={14}/>,
      radio: <CheckSquare size={14}/>
  };

  return (
    <Layout title="Núcleo de Inteligência">
      <div className="w-full">
        
        <div className="mb-8 flex justify-between items-center">
            <p className="text-slate-400">Crie formulários avançados para treinar a IA com regras de negócio.</p>
            <button onClick={handleOpenCreate} className="bg-purple-600 hover:bg-purple-500 text-white px-4 py-2 rounded-lg font-bold flex items-center gap-2 transition shadow-lg shadow-purple-900/20">
                <Plus size={18} /> Novo Formulário
            </button>
        </div>

        {loading ? (
            <div className="text-center text-slate-500 py-10">Carregando bases...</div>
        ) : bases.length === 0 ? (
            <div className="text-center py-20 bg-slate-900/50 rounded-2xl border border-slate-800 border-dashed">
                <Brain size={48} className="mx-auto text-slate-600 mb-4"/>
                <h3 className="text-slate-300 font-medium">Nenhum treinamento criado</h3>
                <p className="text-slate-500 text-sm mt-2">Clique em "Novo Formulário" para começar.</p>
            </div>
        ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {bases.map(base => (
                    <div key={base.id} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-lg hover:border-slate-700 transition group flex flex-col relative">
                        
                        {/* Header do Card */}
                        <div className="flex items-start justify-between mb-4">
                            <div className="flex items-center gap-3">
                                <div className="bg-purple-500/10 p-3 rounded-xl text-purple-500">
                                    <FileText size={24} />
                                </div>
                                <div>
                                    <h3 className="text-lg font-bold text-white truncate max-w-[150px]">{base.name}</h3>
                                    <p className="text-xs text-slate-500">{base.questions.length} perguntas</p>
                                </div>
                            </div>
                            
                            {/* AÇÕES DE CRUD NO CARD */}
                            <div className="flex gap-1">
                                <button 
                                    onClick={() => handleOpenEdit(base)}
                                    className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition"
                                    title="Editar"
                                >
                                    <Edit size={16}/>
                                </button>
                                <button 
                                    onClick={() => handleDelete(base.id)}
                                    className="p-2 text-slate-400 hover:text-red-400 hover:bg-red-900/20 rounded-lg transition"
                                    title="Excluir"
                                >
                                    <Trash2 size={16}/>
                                </button>
                            </div>
                        </div>
                        
                        {/* Preview das Perguntas */}
                        <div className="space-y-2 mb-4 flex-1">
                            {base.questions.slice(0, 3).map((q, i) => (
                                <div key={i} className="text-sm text-slate-400 border-l-2 border-slate-800 pl-2 flex items-center gap-2">
                                    <span className="text-purple-500 opacity-50">{typeIcons[q.type]}</span>
                                    <span className="truncate">{q.text}</span>
                                </div>
                            ))}
                            {base.questions.length > 3 && <p className="text-xs text-slate-600 pl-2">e mais {base.questions.length - 3}...</p>}
                        </div>
                    </div>
                ))}
            </div>
        )}

        {/* MODAL (CREATE / EDIT) */}
        {isModalOpen && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setIsModalOpen(false)}></div>
            <div className="relative bg-slate-900 border border-slate-700 w-full max-w-3xl rounded-2xl shadow-2xl flex flex-col max-h-[90vh]">
                
                <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-900 rounded-t-2xl">
                    <h3 className="text-xl font-bold text-white">
                        {editingId ? 'Editar Treinamento' : 'Novo Treinamento'}
                    </h3>
                    <button onClick={() => setIsModalOpen(false)}><X className="text-slate-400 hover:text-white"/></button>
                </div>

                <div className="p-6 overflow-y-auto flex-1 space-y-6">
                    <div>
                        <label className="block text-sm font-medium text-slate-400 mb-1">Nome do Formulário</label>
                        <input 
                            type="text" 
                            placeholder="Ex: Tabela de Preços e Serviços" 
                            value={formName} 
                            onChange={e => setFormName(e.target.value)} 
                            className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2 text-white outline-none focus:border-purple-500 transition" 
                        />
                    </div>

                    <div className="space-y-4">
                        {questions.map((q, index) => (
                            <div key={q.id} className="bg-slate-950 border border-slate-800 rounded-xl p-4 animate-scale-up">
                                <div className="flex gap-3 items-start mb-3">
                                    <div className="flex-1">
                                        <input 
                                            type="text" 
                                            value={q.text}
                                            onChange={e => updateQuestion(q.id, 'text', e.target.value)}
                                            placeholder={`Pergunta ${index + 1}`}
                                            className="w-full bg-transparent border-b border-slate-800 focus:border-purple-500 py-1 text-white outline-none transition"
                                        />
                                    </div>
                                    <div className="relative w-40">
                                        <select 
                                            value={q.type}
                                            onChange={e => updateQuestion(q.id, 'type', e.target.value)}
                                            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-xs text-slate-300 outline-none appearance-none cursor-pointer hover:border-slate-500"
                                        >
                                            <option value="short_text">Texto Curto</option>
                                            <option value="long_text">Texto Longo</option>
                                            <option value="select">Lista Suspensa</option>
                                            <option value="radio">Múltipla Escolha</option>
                                        </select>
                                        <ChevronDown size={12} className="absolute right-2 top-2 text-slate-500 pointer-events-none"/>
                                    </div>
                                    <button onClick={() => removeQuestion(q.id)} className="text-slate-600 hover:text-red-400 pt-1 transition"><Trash2 size={16}/></button>
                                </div>
                                {(q.type === 'select' || q.type === 'radio') && (
                                    <div className="ml-2 pl-4 border-l-2 border-slate-800">
                                        <p className="text-xs text-slate-500 mb-2">Opções:</p>
                                        <div className="flex flex-wrap gap-2 mb-2">
                                            {q.options.map((opt, i) => (
                                                <span key={i} className="bg-slate-800 text-slate-300 text-xs px-2 py-1 rounded flex items-center gap-1">
                                                    {opt} <button onClick={() => removeOption(q.id, i)} className="hover:text-red-400"><X size={10}/></button>
                                                </span>
                                            ))}
                                        </div>
                                        <input type="text" placeholder="+ Opção e Enter" className="bg-transparent text-xs text-white outline-none placeholder-slate-600" onKeyDown={(e) => { if (e.key === 'Enter') { addOption(q.id, e.currentTarget.value); e.currentTarget.value = ''; } }} />
                                    </div>
                                )}
                            </div>
                        ))}
                        <button onClick={addQuestion} className="w-full py-3 border border-dashed border-slate-700 rounded-xl text-slate-500 hover:text-purple-400 hover:border-purple-500/50 hover:bg-purple-500/5 transition flex justify-center items-center gap-2">
                            <Plus size={16}/> Adicionar Pergunta
                        </button>
                    </div>
                </div>

                <div className="p-6 border-t border-slate-800 bg-slate-900 rounded-b-2xl flex justify-end gap-3">
                    <button onClick={() => setIsModalOpen(false)} className="px-4 py-2 text-slate-300 hover:bg-slate-800 rounded-lg">Cancelar</button>
                    <button onClick={handleSave} disabled={isSaving} className="px-6 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-lg flex items-center gap-2 transition disabled:opacity-70">
                        {isSaving ? <Loader2 size={18} className="animate-spin"/> : <Save size={18}/>} {editingId ? 'Salvar Alterações' : 'Criar Formulário'}
                    </button>
                </div>
            </div>
            </div>
        )}
      </div>
    </Layout>
  );
}