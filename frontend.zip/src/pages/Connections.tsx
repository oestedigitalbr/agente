import { useEffect, useState } from 'react';
import Layout from '../components/Layout';
import api from '../services/api';
import { MessageCircle, Plus, Trash2, Key, Hash, Smartphone, Loader2 } from 'lucide-react';

interface WhatsAppInstance {
  id: string;
  name: string;
  phone_number_id: string;
  status: string;
}

export default function Connections() {
  const [instances, setInstances] = useState<WhatsAppInstance[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  // Form States
  const [name, setName] = useState('');
  const [phoneId, setPhoneId] = useState('');
  const [token, setToken] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  async function loadInstances() {
    try {
      const response = await api.get('/api/whatsapp');
      setInstances(response.data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadInstances(); }, []);

  async function handleConnect(e: React.FormEvent) {
    e.preventDefault();
    setIsSaving(true);
    try {
      await api.post('/api/whatsapp', {
        name,
        phone_number_id: phoneId,
        access_token: token
      });
      setIsModalOpen(false);
      setName(''); setPhoneId(''); setToken('');
      loadInstances();
      alert('WhatsApp conectado via Meta API!');
    } catch (error: any) {
      // --- AQUI ESTÁ A MELHORIA: Mostra o erro real ---
      const msg = error.response?.data?.error || 'Erro desconhecido ao conectar.';
      alert('Ops! ' + msg);
      console.error(error);
    } finally {
      setIsSaving(false);
    }
  }

  async function handleDelete(id: string) {
    if(!confirm('Desconectar este número?')) return;
    try {
      await api.delete(`/api/whatsapp/${id}`);
      loadInstances();
    } catch (error) {
      alert('Erro ao desconectar');
    }
  }

  return (
    <Layout title="Conexões WhatsApp (Meta API)">
      <div className="w-full">
        <div className="mb-8 flex justify-between items-center">
          <p className="text-slate-400">Gerencie seus números conectados via API Oficial.</p>
          <button onClick={() => setIsModalOpen(true)} className="bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-lg font-bold flex items-center gap-2 transition shadow-lg shadow-emerald-900/20">
              <Plus size={18} /> Nova Conexão
          </button>
        </div>

        {loading ? (
          <div className="text-center text-slate-500 py-10">Carregando conexões...</div>
        ) : instances.length === 0 ? (
          <div className="text-center py-20 bg-slate-900/50 rounded-2xl border border-slate-800 border-dashed">
              <Smartphone size={48} className="mx-auto text-slate-600 mb-4"/>
              <h3 className="text-slate-300 font-medium">Nenhum WhatsApp conectado</h3>
              <p className="text-slate-500 text-sm mt-2">Clique em "Nova Conexão" para adicionar via Meta API.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {instances.map(inst => (
                  <div key={inst.id} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-lg relative overflow-hidden group hover:border-slate-700 transition">
                      <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition">
                          <MessageCircle size={80} />
                      </div>
                      
                      <div className="flex items-center justify-between mb-4">
                          <div className="bg-emerald-500/10 p-3 rounded-xl text-emerald-500">
                              <Smartphone size={24} />
                          </div>
                          <span className="text-xs bg-emerald-500/20 text-emerald-300 px-2 py-1 rounded border border-emerald-500/30 flex items-center gap-1">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span> Online
                          </span>
                      </div>
                      
                      <h3 className="text-lg font-bold text-white mb-1">{inst.name}</h3>
                      <p className="text-xs text-slate-500 font-mono mb-6 truncate" title={inst.phone_number_id}>ID: {inst.phone_number_id}</p>

                      <button onClick={() => handleDelete(inst.id)} className="w-full py-2 border border-red-900/30 text-red-400 hover:bg-red-900/20 hover:border-red-900/50 rounded-lg text-sm transition flex items-center justify-center gap-2">
                          <Trash2 size={16} /> Desconectar
                      </button>
                  </div>
              ))}
          </div>
        )}

        {/* MODAL DE CONEXÃO META API */}
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setIsModalOpen(false)}></div>
            <div className="relative bg-slate-900 border border-slate-700 w-full max-w-lg rounded-2xl shadow-2xl p-6 animate-scale-up">
              <h3 className="text-xl font-bold text-white mb-6">Conectar WhatsApp Business</h3>
              <form onSubmit={handleConnect} className="space-y-4">
                  
                  <div>
                      <label className="block text-sm font-medium text-slate-400 mb-1">Nome de Identificação</label>
                      <input type="text" placeholder="Ex: Comercial Principal" value={name} onChange={e => setName(e.target.value)} className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-white outline-none focus:border-emerald-500 transition" required autoFocus />
                  </div>

                  <div>
                      <label className="block text-sm font-medium text-slate-400 mb-1 flex items-center gap-2"><Hash size={14}/> Phone Number ID</label>
                      <input type="text" placeholder="Cole o ID do telefone da Meta" value={phoneId} onChange={e => setPhoneId(e.target.value)} className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-white outline-none focus:border-emerald-500 transition font-mono text-sm" required />
                  </div>

                  <div>
                      <label className="block text-sm font-medium text-slate-400 mb-1 flex items-center gap-2"><Key size={14}/> Access Token (Permanente)</label>
                      <input type="text" placeholder="EAAG..." value={token} onChange={e => setToken(e.target.value)} className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-white outline-none focus:border-emerald-500 transition font-mono text-sm" required />
                  </div>

                  <div className="pt-4 flex justify-end gap-3 border-t border-slate-800 mt-6">
                      <button type="button" onClick={() => setIsModalOpen(false)} className="px-4 py-2 text-slate-300 hover:bg-slate-800 rounded-lg transition">Cancelar</button>
                      <button type="submit" disabled={isSaving} className="px-6 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg flex items-center gap-2 transition shadow-lg shadow-emerald-900/20 disabled:opacity-70">
                          {isSaving && <Loader2 size={16} className="animate-spin"/>} Salvar Conexão
                      </button>
                  </div>

              </form>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}