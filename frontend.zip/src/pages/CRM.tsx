import { useEffect, useState } from 'react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import type { DropResult } from '@hello-pangea/dnd';
import Layout from '../components/Layout';
import api from '../services/api';
import LeadDetailsModal from '../components/LeadDetailsModal';
import CreateLeadModal from '../components/CreateLeadModal'; 
import { 
  Users, DollarSign, ArrowRight, Phone, Calendar, 
  Search, Filter, Plus, Bot, User, Clock 
} from 'lucide-react';

interface Appointment {
  id: string;
  start_time: string;
  title: string;
}

interface Lead {
  id: string;
  name: string;
  phone: string;
  email: string;
  status: string;
  value?: number;
  agent_paused: boolean;
  follow_up_date?: string;
  pipeline: 'agent' | 'client';
  appointments?: Appointment[]; 
}

interface Column {
  id: string;
  title: string;
  color: string;
}

// --- CONFIGURAÇÃO DAS COLUNAS ---
const AGENT_COLUMNS: Column[] = [
  { id: 'triage', title: 'Triagem (Entrada)', color: 'border-slate-500' },
  { id: 'qualifying', title: 'Em Qualificação', color: 'border-blue-500' },
  { id: 'scheduled', title: 'Agendado/Quente', color: 'border-purple-500' },
  { id: 'handover', title: 'Enviar p/ Comercial ➔', color: 'border-emerald-500 bg-emerald-900/10' }, 
];

const CLIENT_COLUMNS: Column[] = [
  { id: 'new', title: 'Novos Leads', color: 'border-blue-500' },
  { id: 'contacted', title: 'Em Contato', color: 'border-yellow-500' },
  { id: 'proposal', title: 'Proposta Enviada', color: 'border-purple-500' },
  { id: 'negotiation', title: 'Em Negociação', color: 'border-orange-500' },
  { id: 'closed', title: 'Fechado / Ganho', color: 'border-emerald-500' },
  { id: 'lost', title: 'Perdido', color: 'border-red-500' },
];

export default function CRM() {
  const [activePipeline, setActivePipeline] = useState<'agent' | 'client'>('client');
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  async function loadLeads() {
    setLoading(true);
    try {
      const response = await api.get(`/api/crm/board?pipeline=${activePipeline}`);
      if (Array.isArray(response.data)) {
        setLeads(response.data);
      } else {
        setLeads([]);
      }
    } catch (error) {
      console.error("Erro ao carregar leads", error);
      setLeads([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadLeads(); }, [activePipeline]);

  async function onDragEnd(result: DropResult) {
    if (!result.destination) return;
    const { source, destination, draggableId } = result;
    if (source.droppableId === destination.droppableId) return;

    if (activePipeline === 'agent' && destination.droppableId === 'handover') {
        const confirmTransfer = confirm("Transferir este lead para o CRM Comercial?");
        if (!confirmTransfer) {
            loadLeads();
            return;
        }

        try {
            setLeads(leads.filter(l => l.id !== draggableId));
            await api.put(`/api/crm/leads/${draggableId}/move`, { 
                status: 'new', 
                pipeline: 'client' 
            });
            alert("Lead enviado para o Comercial com sucesso!");
        } catch (error) {
            alert("Erro ao transferir lead");
            loadLeads();
        }
        return;
    }

    const updatedLeads = leads.map(lead => 
      lead.id === draggableId ? { ...lead, status: destination.droppableId } : lead
    );
    setLeads(updatedLeads);

    try {
      await api.put(`/api/crm/leads/${draggableId}/move`, { status: destination.droppableId });
    } catch (error) {
      loadLeads();
    }
  }

  const currentColumns = activePipeline === 'agent' ? AGENT_COLUMNS : CLIENT_COLUMNS;

  function formatShortDate(dateStr: string) {
      const date = new Date(dateStr);
      return date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }) + ' ' + 
             date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  }

  return (
    <Layout title="Gestão de Leads (CRM)">
      <div className="flex flex-col h-full overflow-hidden"> {/* FIX: overflow-hidden aqui ajuda a conter scrolls externos */}
        
        {/* HEADER */}
        <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4 shrink-0">
            <div className="flex bg-slate-900 p-1 rounded-xl border border-slate-800">
                <button 
                    onClick={() => setActivePipeline('agent')}
                    className={`px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 transition ${activePipeline === 'agent' ? 'bg-purple-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}
                >
                    <Bot size={18}/> CRM Agente (IA)
                </button>
                <button 
                    onClick={() => setActivePipeline('client')}
                    className={`px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 transition ${activePipeline === 'client' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}
                >
                    <User size={18}/> CRM Comercial
                </button>
            </div>

            <div className="flex gap-3">
                <button 
                    onClick={() => setIsCreateModalOpen(true)}
                    className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold text-sm shadow-lg shadow-emerald-900/20 transition"
                >
                    <Plus size={18}/> Add Lead
                </button>
            </div>
        </div>

        {/* KANBAN BOARD */}
        <DragDropContext onDragEnd={onDragEnd}>
          <div className="flex gap-4 overflow-x-auto pb-4 h-full snap-x">
            {currentColumns.map(col => (
              // FIX: O Wrapper da coluna fica FORA do Droppable
              <div 
                key={col.id}
                className={`flex-shrink-0 w-80 bg-slate-900/50 rounded-xl border-t-4 ${col.color} flex flex-col h-full max-h-[calc(100vh-240px)] snap-center transition-colors ${col.id === 'handover' ? 'border-dashed border-2 bg-emerald-900/5' : ''}`}
              >
                {/* CABEÇALHO (Fixo, fora do scroll) */}
                <div className="p-4 border-b border-slate-800 bg-slate-900/80 rounded-t-lg backdrop-blur-sm flex justify-between items-center shrink-0">
                    <h3 className="font-bold text-slate-200">{col.title}</h3>
                    <span className="bg-slate-800 text-slate-400 text-xs px-2 py-1 rounded-full">
                        {Array.isArray(leads) ? leads.filter(l => l.status === col.id).length : 0}
                    </span>
                </div>

                {/* LISTA DE CARDS (Droppable é só a área que rola) */}
                <Droppable droppableId={col.id}>
                  {(provided, snapshot) => (
                    <div
                        ref={provided.innerRef}
                        {...provided.droppableProps}
                        className={`p-3 flex-1 overflow-y-auto space-y-3 scrollbar-thin scrollbar-thumb-slate-800 ${snapshot.isDraggingOver ? 'bg-slate-800/20' : ''}`}
                    >
                        {Array.isArray(leads) && leads
                            .filter(l => l.status === col.id)
                            .map((lead, index) => {
                                const nextApt = lead.appointments && lead.appointments.length > 0 ? lead.appointments[0] : null;

                                return (
                                <Draggable key={lead.id} draggableId={lead.id} index={index}>
                                    {(provided, snapshot) => (
                                        <div
                                            ref={provided.innerRef}
                                            {...provided.draggableProps}
                                            {...provided.dragHandleProps}
                                            onClick={() => setSelectedLead(lead)}
                                            style={{ ...provided.draggableProps.style }} // Estilo essencial para o drag funcionar
                                            className={`bg-slate-950 p-4 rounded-lg border border-slate-800 shadow-sm hover:border-blue-500/50 cursor-pointer group transition-all relative ${snapshot.isDragging ? 'rotate-2 scale-105 shadow-2xl z-50 border-blue-500' : ''}`}
                                        >
                                            <div className="flex justify-between items-start mb-2">
                                                <span className="font-bold text-white group-hover:text-blue-400 transition truncate">{lead.name}</span>
                                                {lead.agent_paused && (
                                                    <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" title="Atendimento Humano Ativo"></span>
                                                )}
                                            </div>
                                            
                                            <div className="space-y-1 mb-3">
                                                <div className="flex items-center text-xs text-slate-500">
                                                    <Phone size={12} className="mr-2"/> {lead.phone}
                                                </div>
                                                {lead.value && lead.value > 0 && (
                                                    <div className="flex items-center text-xs text-emerald-500 font-medium">
                                                        <DollarSign size={12} className="mr-2"/> 
                                                        {lead.value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                                                    </div>
                                                )}
                                            </div>

                                            {/* AGENDAMENTOS E FOLLOW-UP */}
                                            <div className="pt-3 mt-2 border-t border-slate-900 flex flex-col gap-2">
                                                {nextApt && (
                                                    <div className="flex items-center text-emerald-400 gap-2 bg-emerald-900/10 p-1.5 rounded -mx-1">
                                                        <Calendar size={14} className="shrink-0" />
                                                        <span className="text-[11px] font-bold uppercase tracking-wider truncate">
                                                            {formatShortDate(nextApt.start_time)}
                                                        </span>
                                                    </div>
                                                )}

                                                {lead.follow_up_date && (
                                                    <div className="flex items-center text-amber-500 gap-2 bg-amber-900/10 p-1.5 rounded -mx-1">
                                                        <Clock size={14} className="shrink-0" />
                                                        <span className="text-[11px] font-bold uppercase tracking-wider truncate">
                                                            Follow-up: {formatShortDate(lead.follow_up_date)}
                                                        </span>
                                                    </div>
                                                )}

                                                {!nextApt && !lead.follow_up_date && (
                                                    <span className="text-[10px] text-slate-600 uppercase font-bold tracking-wider block pt-1">
                                                        Sem agendamento
                                                    </span>
                                                )}
                                            </div>
                                        </div>
                                    )}
                                </Draggable>
                            )})}
                        {provided.placeholder}
                        
                        {col.id === 'handover' && Array.isArray(leads) && leads.filter(l => l.status === col.id).length === 0 && (
                            <div className="text-center text-slate-600 text-xs mt-4 italic border border-dashed border-slate-700 p-4 rounded select-none">
                                Arraste aqui para enviar ao Comercial
                            </div>
                        )}
                    </div>
                  )}
                </Droppable>
              </div>
            ))}
          </div>
        </DragDropContext>

        {selectedLead && (
            <LeadDetailsModal 
                isOpen={!!selectedLead} 
                onClose={() => setSelectedLead(null)} 
                lead={selectedLead}
                onUpdate={loadLeads}
            />
        )}

        <CreateLeadModal
            isOpen={isCreateModalOpen}
            onClose={() => setIsCreateModalOpen(false)}
            onSuccess={loadLeads}
            activePipeline={activePipeline}
        />

      </div>
    </Layout>
  );
}