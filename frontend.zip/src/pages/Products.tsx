import { useEffect, useState } from 'react';
import Layout from '../components/Layout';
import api from '../services/api';
import CreateProductModal from '../components/CreateProductModal';
import { Plus, Package, MoreHorizontal, Edit, Trash2 } from 'lucide-react';

interface Product {
  id: string;
  name: string;
  price: string;
  sku: string | null;
  description?: string;
  image_url?: string | null;
}

export default function Products() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [productToEdit, setProductToEdit] = useState<Product | null>(null);
  const [openMenuId, setOpenMenuId] = useState<string | null>(null);

  async function loadProducts() {
    setLoading(true);
    try {
      const response = await api.get('/api/products');
      setProducts(response.data);
    } catch (error) {
      console.error("Erro ao carregar", error);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadProducts(); }, []);

  function handleEdit(product: Product) {
    setProductToEdit(product);
    setOpenMenuId(null);
    setIsModalOpen(true);
  }

  async function handleDelete(id: string) {
    if (!confirm('Tem certeza que deseja apagar?')) return;
    try {
      await api.delete(`/api/products/${id}`);
      setProducts(products.filter(p => p.id !== id));
    } catch (error) {
      alert('Erro ao excluir.');
    }
  }

  function handleNewProduct() {
    setProductToEdit(null);
    setIsModalOpen(true);
  }

  return (
    <Layout title="Catálogo de Produtos">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-10" onClick={() => setOpenMenuId(null)}>
        <p className="text-slate-400 max-w-lg">
          Gerencie seu inventário. A IA usará essas informações nas vendas.
        </p>
        <button onClick={handleNewProduct} className="bg-blue-600 hover:bg-blue-500 text-white px-6 py-3 rounded-xl flex items-center gap-2 font-bold transition shadow-lg shadow-blue-900/40 hover:scale-105">
          <Plus size={20} /> Novo Produto
        </button>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map(i => <div key={i} className="h-64 bg-slate-800/50 rounded-2xl animate-pulse"></div>)}
        </div>
      ) : products.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 bg-slate-900/50 rounded-3xl border border-dashed border-slate-700">
          <div className="bg-slate-800 p-4 rounded-full mb-4"><Package className="w-10 h-10 text-slate-500" /></div>
          <h3 className="text-lg font-medium text-white">Nenhum produto</h3>
          <button onClick={handleNewProduct} className="text-blue-400 font-semibold text-sm hover:underline mt-2">Cadastrar agora</button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {products.map((prod) => (
            <div key={prod.id} className="group bg-slate-900 border border-slate-800 rounded-2xl p-5 hover:border-blue-500/50 transition-all duration-300 hover:shadow-2xl flex flex-col justify-between h-full relative">
              <div>
                <div className="flex justify-between items-start mb-4 relative">
                  {prod.image_url ? (
                    <div className="w-16 h-16 rounded-xl border border-slate-700 overflow-hidden">
                      <img src={`http://localhost:8000${prod.image_url}`} alt={prod.name} className="w-full h-full object-cover"/>
                    </div>
                  ) : (
                    <div className="w-16 h-16 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center"><Package className="text-slate-500" size={24} /></div>
                  )}

                  <div className="relative">
                    <button onClick={(e) => { e.stopPropagation(); setOpenMenuId(openMenuId === prod.id ? null : prod.id); }} className="text-slate-400 hover:text-white bg-slate-800 p-1.5 rounded-lg transition"><MoreHorizontal size={20} /></button>
                    {openMenuId === prod.id && (
                        <div className="absolute right-0 top-10 w-32 bg-slate-800 border border-slate-700 rounded-lg shadow-xl z-20 overflow-hidden">
                            <button onClick={() => handleEdit(prod)} className="w-full text-left px-4 py-2 text-sm text-slate-300 hover:bg-slate-700 flex items-center gap-2"><Edit size={14}/> Editar</button>
                            <button onClick={() => handleDelete(prod.id)} className="w-full text-left px-4 py-2 text-sm text-red-400 hover:bg-red-900/20 flex items-center gap-2"><Trash2 size={14}/> Excluir</button>
                        </div>
                    )}
                  </div>
                </div>
                <h3 className="font-bold text-slate-100 text-lg mb-2 leading-tight line-clamp-2">{prod.name}</h3>
                <p className="text-slate-400 text-sm mb-4 line-clamp-3 min-h-[60px]">{prod.description || 'Sem descrição.'}</p>
              </div>
              <div className="mt-4 pt-4 border-t border-slate-800 flex items-center justify-between">
                <span className="text-xs font-mono text-slate-500 bg-slate-800 px-2 py-1 rounded">{prod.sku || 'N/A'}</span>
                <p className="text-lg font-bold text-emerald-400">{Number(prod.price).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p>
              </div>
            </div>
          ))}
        </div>
      )}
      <CreateProductModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onSuccess={loadProducts} productToEdit={productToEdit} />
    </Layout>
  );
}