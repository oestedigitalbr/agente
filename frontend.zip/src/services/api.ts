import axios from 'axios';

const api = axios.create({
    baseURL: 'http://localhost:8000', // Endereço do seu Backend
    headers: {
        'Content-Type': 'application/json',
    },
});

// Interceptor: Antes de cada chamada, verifica se tem token salvo e anexa
api.interceptors.request.use((config) => {
    const token = localStorage.getItem('agenteup4_token');
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});

export default api;