import { useState } from 'react';
import { X, User, Phone, Mail, DollarSign, Loader2, Save } from 'lucide-react';
import api from '../services/api';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  activePipeline: 'agent' | 'client'; // Para saber onde criar o lead
}

export default function CreateLeadModal({ isOpen, onClose, onSuccess, activePipeline }: ModalProps) {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [value, setValue] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  if (!isOpen) return null;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    
    if (!name || !phone) {
        alert('Nome e Telefone são obrigatórios!');
        return;
    }

    setIsSaving(true);
    try {
      await api.post('/api/crm/leads', {
        name,
        phone,
        email,
        value: parseFloat(value) || 0,
        // Se for Pipeline Agente, nasce em 'triage'. Se for Cliente, nasce em 'new'.
        status: activePipeline === 'agent' ? 'triage' : 'new',
        pipeline: activePipeline
      });

      // Limpa e fecha
      setName(''); setPhone(''); setEmail(''); setValue('');
      onSuccess(); // Recarrega o Kanban
      onClose();   // Fecha modal
    } catch (error: any) {
      // MUDANÇA AQUI: Captura a mensagem real do PHP
      const msg = error.response?.data?.error || error.response?.data?.details || 'Erro desconhecido ao criar lead.';
      alert('Ops! ' + msg);
      console.error(error);
    } finally {
      setIsSaving(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose}></div>
      <div className="relative bg-slate-900 border border-slate-700 w-full max-w-lg rounded-2xl shadow-2xl animate-scale-up">
        
        {/* Header */}
        <div className="p-6 border-b border-slate-800 flex justify-between items-center">
            <h3 className="text-xl font-bold text-white">Novo Lead ({activePipeline === 'agent' ? 'IA' : 'Comercial'})</h3>
            <button onClick={onClose}><X className="text-slate-400 hover:text-white"/></button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
            
            <div>
                <label className="block text-sm text-slate-400 mb-1 flex items-center gap-2">
                    <User size={14}/> Nome do Cliente *
                </label>
                <input 
                    type="text" 
                    required
                    placeholder="Ex: João da Silva"
                    value={name} onChange={e => setName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-white outline-none focus:border-blue-500 transition"
                    autoFocus
                />
            </div>

            <div>
                <label className="block text-sm text-slate-400 mb-1 flex items-center gap-2">
                    <Phone size={14}/> WhatsApp / Telefone *
                </label>
                <input 
                    type="text" 
                    required
                    placeholder="Ex: 5511999999999 (Apenas números)"
                    value={phone} onChange={e => setPhone(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-white outline-none focus:border-blue-500 transition"
                />
            </div>

            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm text-slate-400 mb-1 flex items-center gap-2">
                        <Mail size={14}/> Email (Opcional)
                    </label>
                    <input 
                        type="email" 
                        placeholder="cliente@email.com"
                        value={email} onChange={e => setEmail(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-white outline-none focus:border-blue-500 transition"
                    />
                </div>
                <div>
                    <label className="block text-sm text-slate-400 mb-1 flex items-center gap-2">
                        <DollarSign size={14}/> Valor Potencial
                    </label>
                    <input 
                        type="number" 
                        placeholder="0.00"
                        value={value} onChange={e => setValue(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-white outline-none focus:border-blue-500 transition"
                    />
                </div>
            </div>

            <div className="pt-4 flex justify-end gap-3 border-t border-slate-800 mt-2">
                <button type="button" onClick={onClose} className="px-4 py-2 text-slate-300 hover:bg-slate-800 rounded-lg">Cancelar</button>
                <button type="submit" disabled={isSaving} className="px-6 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg flex items-center gap-2 transition disabled:opacity-70">
                    {isSaving ? <Loader2 size={18} className="animate-spin"/> : <Save size={18}/>} Salvar Lead
                </button>
            </div>

        </form>
      </div>
    </div>
  );
}