import { ReactNode, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, ShoppingBag, Users, Bot, Calendar, 
  LogOut, Menu, X, Bell, Search, ChevronDown, Smartphone, Brain 
} from 'lucide-react';

interface LayoutProps {
  children: ReactNode;
  title: string;
}

export default function Layout({ children, title }: LayoutProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  // Evita crash se localStorage estiver vazio
  const user = JSON.parse(localStorage.getItem('agenteup4_user') || '{}');

  const menuItems = [
    { label: 'Dashboard', icon: LayoutDashboard, path: '/dashboard' },
    { label: 'CRM & Leads', icon: Users, path: '/crm' },
    { label: 'Agentes IA', icon: Bot, path: '/agents' },
    { label: 'Inteligência', icon: Brain, path: '/intelligence' }, // Rota de Treinamento
    { label: 'Conexões WP', icon: Smartphone, path: '/connections' }, // Rota de WhatsApp API
    { label: 'Produtos', icon: ShoppingBag, path: '/products' },
    { label: 'Agenda', icon: Calendar, path: '/agenda' },
  ];

  function handleLogout() {
    localStorage.clear();
    window.location.href = '/';
  }

  return (
    <div className="flex h-screen bg-slate-950 text-slate-100 font-sans overflow-hidden">
      
      {/* === SIDEBAR (Desktop) === */}
      <aside className="hidden md:flex w-72 flex-col bg-slate-900/50 backdrop-blur-xl border-r border-slate-800 flex-shrink-0 transition-all duration-300">
        
        {/* Logo */}
        <div className="p-6 flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-violet-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/20">
            <Bot className="text-white" size={24} />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight">AgenteUP4</h1>
            <p className="text-xs text-slate-400">Intelligence System</p>
          </div>
        </div>

        {/* Menu de Navegação */}
        <nav className="flex-1 px-4 py-4 space-y-1 overflow-y-auto scrollbar-thin scrollbar-thumb-slate-800">
          {menuItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <button
                key={item.path}
                onClick={() => navigate(item.path)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group ${
                  isActive 
                    ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/20' 
                    : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <item.icon size={20} className={isActive ? 'animate-pulse' : 'group-hover:scale-110 transition-transform'} />
                <span className="font-medium">{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* User Profile Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/30">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-r from-emerald-400 to-cyan-500 flex items-center justify-center font-bold text-slate-900 shadow-lg">
                {user.name?.[0]?.toUpperCase() || 'A'}
              </div>
              <div className="overflow-hidden">
                <p className="text-sm font-semibold truncate w-24">{user.name || 'Admin'}</p>
                <p className="text-xs text-slate-400 capitalize">{user.role || 'Owner'}</p>
              </div>
            </div>
            <button 
              onClick={handleLogout}
              className="p-2 hover:bg-red-500/10 hover:text-red-400 rounded-lg transition-colors"
              title="Sair do Sistema"
            >
              <LogOut size={18} />
            </button>
          </div>
        </div>
      </aside>

      {/* === ÁREA PRINCIPAL (Conteúdo) === */}
      {/* 'min-w-0' é o segredo para o flexbox não estourar a largura em telas menores */}
      <main className="flex-1 flex flex-col h-full overflow-hidden relative min-w-0 bg-slate-950">
        
        {/* Header Superior */}
        <header className="h-20 bg-slate-900/50 backdrop-blur-md border-b border-slate-800 flex items-center justify-between px-6 z-20 flex-shrink-0">
          
          {/* Menu Mobile Button */}
          <div className="md:hidden flex items-center gap-4">
            <button onClick={() => setIsMobileMenuOpen(true)} className="text-slate-300 hover:text-white transition">
              <Menu size={24} />
            </button>
            <span className="font-bold text-lg">AgenteUP4</span>
          </div>

          {/* Barra de Busca (Desktop) */}
          <div className="hidden md:flex items-center bg-slate-800/50 rounded-lg px-4 py-2 w-96 border border-slate-700 focus-within:border-blue-500 transition-all shadow-sm">
            <Search size={18} className="text-slate-500 mr-3" />
            <input type="text" placeholder="Buscar no sistema..." className="bg-transparent border-none outline-none text-sm w-full placeholder-slate-500 text-slate-200" />
          </div>

          {/* Ações do Header */}
          <div className="flex items-center gap-4">
            <button className="relative p-2 text-slate-400 hover:text-white transition bg-slate-800/50 rounded-lg hover:bg-slate-800">
              <Bell size={20} />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border-2 border-slate-900 shadow-md"></span>
            </button>
            
            <div className="h-8 w-px bg-slate-800 hidden md:block"></div>
            
            <div className="hidden md:flex items-center gap-2 cursor-pointer hover:bg-slate-800 p-2 rounded-lg transition select-none">
              <span className="text-sm font-medium">Minha Empresa</span>
              <ChevronDown size={16} className="text-slate-500" />
            </div>
          </div>
        </header>

        {/* === CONTEÚDO SCROLLÁVEL === */}
        <div className="flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-slate-700 scrollbar-track-transparent">
          
          {/* AQUI ESTÁ A CORREÇÃO DO LAYOUT:
              w-full: Garante largura total.
          */}
          <div className="w-full h-full p-6 md:p-8"> 
             
             {/* Título da Página */}
             <div className="flex justify-between items-end mb-8 w-full border-b border-slate-800/50 pb-4">
               <h2 className="text-3xl font-bold text-white tracking-tight">{title}</h2>
             </div>
             
             {/* Renderização das Páginas Filhas */}
             <div className="w-full animate-fade-in-up">
                {children}
             </div>

          </div>
        </div>

        {/* === MOBILE MENU OVERLAY === */}
        {isMobileMenuOpen && (
          <div className="absolute inset-0 z-50 md:hidden">
            <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setIsMobileMenuOpen(false)}></div>
            <div className="absolute left-0 top-0 bottom-0 w-72 bg-slate-900 border-r border-slate-800 p-6 shadow-2xl flex flex-col h-full animate-slide-in-left">
              
              <div className="flex justify-between items-center mb-8">
                <span className="font-bold text-xl flex items-center gap-2">
                   <Bot className="text-blue-500" /> Menu
                </span>
                <button onClick={() => setIsMobileMenuOpen(false)} className="text-slate-400 hover:text-white"><X size={24} /></button>
              </div>
              
              <nav className="space-y-2 flex-1 overflow-y-auto">
                {menuItems.map((item) => (
                  <button
                    key={item.path}
                    onClick={() => { navigate(item.path); setIsMobileMenuOpen(false); }}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                      location.pathname === item.path ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-slate-800'
                    }`}
                  >
                    <item.icon size={20} /> {item.label}
                  </button>
                ))}
              </nav>

              <div className="mt-4 pt-4 border-t border-slate-800">
                  <button onClick={handleLogout} className="flex items-center gap-3 text-red-400 px-4 py-2 hover:bg-slate-800 rounded-lg w-full">
                      <LogOut size={20}/> Sair
                  </button>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}