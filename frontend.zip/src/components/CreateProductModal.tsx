import { useState, useRef, useEffect } from 'react';
import { X, Sparkles, Save, Loader2, Upload, Image as ImageIcon } from 'lucide-react';
import api from '../services/api';

interface Product {
  id: string;
  name: string;
  price: string;
  sku: string | null;
  description?: string;
  image_url?: string | null;
}

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  productToEdit?: Product | null;
}

export default function CreateProductModal({ isOpen, onClose, onSuccess, productToEdit }: ModalProps) {
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [sku, setSku] = useState('');
  const [description, setDescription] = useState('');
  
  const [imageFile, setImageFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (isOpen) {
      if (productToEdit) {
        setName(productToEdit.name);
        // Formata preço para o visual brasileiro
        const priceFormatted = Number(productToEdit.price).toLocaleString('pt-BR', { minimumFractionDigits: 2 });
        setPrice(priceFormatted);
        setSku(productToEdit.sku || '');
        setDescription(productToEdit.description || '');
        setImageFile(null);
      } else {
        setName(''); setPrice(''); setSku(''); setDescription(''); setImageFile(null);
      }
    }
  }, [isOpen, productToEdit]);

  if (!isOpen) return null;

  async function handleGenerateAI() {
    if (!name) return alert('Digite o nome do produto primeiro!');
    setIsGenerating(true);
    try {
      const prompt = `Crie uma descrição curta e persuasiva para vender: "${name}". Use emojis.`;
      const response = await api.post('/api/ai/generate', { prompt });
      setDescription(response.data.data);
    } catch (error) {
      alert('Erro ao gerar descrição com IA.');
    } finally {
      setIsGenerating(false);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setIsSaving(true);

    try {
      const formData = new FormData();
      formData.append('name', name);
      formData.append('description', description);
      formData.append('sku', sku);
      formData.append('price', price);
      if (imageFile) formData.append('image', imageFile);

      const config = { headers: { 'Content-Type': 'multipart/form-data' } };

      if (productToEdit) {
        await api.post(`/api/products/${productToEdit.id}`, formData, config);
      } else {
        await api.post('/api/products', formData, config);
      }
      
      onSuccess(); 
      onClose();
    } catch (error: any) {
      alert(error.response?.data?.error || 'Erro ao salvar produto.');
    } finally {
      setIsSaving(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose}></div>

      <div className="relative bg-slate-900 border border-slate-700 w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden animate-scale-up max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center p-6 border-b border-slate-800 bg-slate-900 sticky top-0 z-10">
          <h3 className="text-xl font-bold text-white">
            {productToEdit ? 'Editar Produto' : 'Novo Produto'}
          </h3>
          <button onClick={onClose} className="text-slate-400 hover:text-white"><X size={24} /></button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          <div>
            <label className="block text-sm font-medium text-slate-400 mb-2">Imagem</label>
            {!imageFile ? (
              <div onClick={() => fileInputRef.current?.click()} className="border-2 border-dashed border-slate-700 rounded-xl p-6 flex flex-col items-center justify-center cursor-pointer hover:border-blue-500 hover:bg-slate-800/50 transition group">
                <Upload className="text-slate-500 group-hover:text-blue-400 mb-2" size={24} />
                <p className="text-sm text-slate-400">Clique para {productToEdit ? 'alterar' : 'enviar'}</p>
              </div>
            ) : (
              <div className="flex items-center justify-between bg-slate-800 p-3 rounded-xl border border-slate-700">
                 <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-slate-700 rounded-lg flex items-center justify-center"><ImageIcon size={20} className="text-blue-400"/></div>
                    <p className="text-sm text-slate-300 truncate max-w-[200px]">{imageFile.name}</p>
                 </div>
                 <button type="button" onClick={() => {setImageFile(null); if(fileInputRef.current) fileInputRef.current.value = ''}} className="text-red-400 hover:bg-red-900/20 p-1 rounded"><X size={18}/></button>
              </div>
            )}
            <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={(e) => setImageFile(e.target.files?.[0] || null)}/>
          </div>

          <div><label className="block text-sm font-medium text-slate-400 mb-1">Nome</label><input type="text" value={name} onChange={e => setName(e.target.value)} className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2 text-white outline-none focus:border-blue-500" required /></div>
          
          <div className="grid grid-cols-2 gap-4">
            <div><label className="block text-sm font-medium text-slate-400 mb-1">Preço (R$)</label><input type="text" value={price} onChange={e => setPrice(e.target.value)} className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2 text-white outline-none focus:border-blue-500" required /></div>
            <div><label className="block text-sm font-medium text-slate-400 mb-1">SKU</label><input type="text" value={sku} onChange={e => setSku(e.target.value)} className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2 text-white outline-none focus:border-blue-500" /></div>
          </div>

          <div>
             <div className="flex justify-between mb-1"><label className="block text-sm font-medium text-slate-400">Descrição</label><button type="button" onClick={handleGenerateAI} disabled={isGenerating || !name} className="text-xs text-purple-400 flex items-center gap-1 hover:text-purple-300 transition"><Sparkles size={12}/> Gerar com IA</button></div>
             <textarea rows={3} value={description} onChange={e => setDescription(e.target.value)} className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2 text-white outline-none focus:border-blue-500 resize-none"></textarea>
          </div>

          <div className="pt-4 flex justify-end gap-3 border-t border-slate-800 sticky bottom-0 bg-slate-900">
            <button type="button" onClick={onClose} className="px-4 py-2 text-slate-300 hover:bg-slate-800 rounded-lg transition">Cancelar</button>
            <button type="submit" disabled={isSaving} className="px-6 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg flex items-center gap-2 transition disabled:opacity-70">{isSaving && <Loader2 size={16} className="animate-spin"/>} Salvar</button>
          </div>
        </form>
      </div>
    </div>
  );
}