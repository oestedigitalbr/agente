import { useState, useEffect } from 'react';
import { X, Bot, Smartphone, Brain, ChevronRight, Check, Loader2 } from 'lucide-react';
import api from '../services/api';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  agentToEdit?: any; // Novo: Recebe o agente para editar
}

export default function CreateAgentModal({ isOpen, onClose, onSuccess, agentToEdit }: ModalProps) {
  const [step, setStep] = useState(1);
  const [loadingData, setLoadingData] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const [whatsappInstances, setWhatsappInstances] = useState<any[]>([]);
  const [knowledgeBases, setKnowledgeBases] = useState<any[]>([]);

  // Form Data
  const [name, setName] = useState('');
  const [role, setRole] = useState('');
  const [selectedWhatsapp, setSelectedWhatsapp] = useState('');
  const [selectedBase, setSelectedBase] = useState('');
  const [answers, setAnswers] = useState<Record<string, string>>({});

  useEffect(() => {
    if (isOpen) {
      setLoadingData(true);
      
      // Carrega dados auxiliares (WPs e Bases)
      Promise.all([
        api.get('/api/whatsapp'),
        api.get('/api/knowledge-bases')
      ]).then(([wpRes, kbRes]) => {
        setWhatsappInstances(wpRes.data);
        
        // Formata as bases para garantir JSON correto
        const formattedBases = kbRes.data.map((b: any) => ({
            ...b,
            questions: typeof b.questions[0] === 'string' 
                ? b.questions.map((q: string) => ({ text: q, type: 'long_text', options: [] })) 
                : b.questions
        }));
        setKnowledgeBases(formattedBases);
        setLoadingData(false);
      }).catch(() => setLoadingData(false));

      // PREENCHE OS DADOS SE FOR EDIÇÃO
      if (agentToEdit) {
          setName(agentToEdit.name || '');
          setRole(agentToEdit.role || '');
          setSelectedWhatsapp(agentToEdit.whatsapp_instance_id || '');
          setSelectedBase(agentToEdit.knowledge_base_id || '');
          setStep(1); // Começa na aba 1
      } else {
          // RESET SE FOR CRIAÇÃO
          setStep(1); setName(''); setRole(''); setSelectedWhatsapp(''); setSelectedBase(''); setAnswers({});
      }
    }
  }, [isOpen, agentToEdit]);

  if (!isOpen) return null;

  function generatePrompt() {
    let prompt = `Você é ${name}, um ${role}.\n`;
    
    if (selectedBase) {
        const base = knowledgeBases.find(b => b.id === selectedBase);
        if (base && base.questions) {
            prompt += "\nDiretrizes de Comportamento Baseadas em Treinamento:\n";
            // Se estamos editando e não mudamos as respostas, mantemos o prompt antigo ou geramos novo?
            // Simplificação: Gera novo baseado nas respostas atuais
            base.questions.forEach((q: any, idx: number) => {
                const answer = answers[idx] || 'Não especificado (Consulte o histórico)';
                prompt += `- Pergunta: ${q.text}\n  Resposta: ${answer}\n`;
            });
        }
    } else {
        prompt += "\nComporte-se como um assistente profissional e amigável.";
    }
    return prompt;
  }

  async function handleFinish() {
    setIsSaving(true);
    try {
      const payload = {
        name,
        role,
        whatsapp_instance_id: selectedWhatsapp || null,
        knowledge_base_id: selectedBase || null,
        personality: generatePrompt(),
        is_active: true
      };

      if (agentToEdit) {
          // MODO EDIÇÃO (PUT)
          await api.put(`/api/agents/${agentToEdit.id}`, payload);
          alert('Agente atualizado com sucesso!');
      } else {
          // MODO CRIAÇÃO (POST)
          await api.post('/api/agents', payload);
          alert('Agente criado com sucesso!');
      }

      onSuccess();
      onClose();
    } catch (error: any) {
      const msg = error.response?.data?.details || error.response?.data?.error || 'Erro desconhecido';
      alert('Ops! Ocorreu um erro:\n' + msg);
      console.error(error);
    } finally {
      setIsSaving(false);
    }
  }

  const currentBase = knowledgeBases.find(b => b.id === selectedBase);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose}></div>

      <div className="relative bg-slate-900 border border-slate-700 w-full max-w-2xl rounded-2xl shadow-2xl flex flex-col max-h-[90vh]">
        
        <div className="p-6 border-b border-slate-800 flex justify-between items-center">
            <div>
                <h3 className="text-xl font-bold text-white">
                    {agentToEdit ? 'Editar Agente' : 'Novo Agente IA'}
                </h3>
                <div className="flex items-center gap-2 mt-2 text-sm">
                    <span className={`px-2 py-0.5 rounded ${step >= 1 ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-500'}`}>1. Identidade</span>
                    <ChevronRight size={14} className="text-slate-600"/>
                    <span className={`px-2 py-0.5 rounded ${step >= 2 ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-500'}`}>2. Conexão</span>
                    <ChevronRight size={14} className="text-slate-600"/>
                    <span className={`px-2 py-0.5 rounded ${step >= 3 ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-500'}`}>3. Treinamento</span>
                </div>
            </div>
            <button onClick={onClose}><X className="text-slate-400 hover:text-white"/></button>
        </div>

        <div className="p-8 overflow-y-auto flex-1">
            {loadingData ? (
                <div className="flex justify-center items-center h-40"><Loader2 className="animate-spin text-blue-500"/></div>
            ) : (
                <>
                    {/* PASSO 1: IDENTIDADE */}
                    {step === 1 && (
                        <div className="space-y-4 animate-fade-in-up">
                            <div className="bg-blue-500/10 p-4 rounded-xl border border-blue-500/20 mb-6 flex gap-3">
                                <Bot className="text-blue-400 shrink-0"/>
                                <p className="text-sm text-blue-200">Defina quem é o seu agente.</p>
                            </div>
                            <div><label className="block text-sm text-slate-400 mb-1">Nome</label><input type="text" value={name} onChange={e => setName(e.target.value)} className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-white outline-none focus:border-blue-500" autoFocus/></div>
                            <div><label className="block text-sm text-slate-400 mb-1">Cargo</label><input type="text" value={role} onChange={e => setRole(e.target.value)} className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-white outline-none focus:border-blue-500"/></div>
                        </div>
                    )}

                    {/* PASSO 2: CONEXÃO */}
                    {step === 2 && (
                        <div className="space-y-4 animate-fade-in-up">
                            <div className="bg-emerald-500/10 p-4 rounded-xl border border-emerald-500/20 mb-6 flex gap-3"><Smartphone className="text-emerald-400 shrink-0"/><p className="text-sm text-emerald-200">Escolha o WhatsApp.</p></div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                {whatsappInstances.length === 0 ? <div className="col-span-2 text-center py-8 border border-dashed border-slate-700 rounded-xl text-slate-500">Nenhum WhatsApp conectado.</div> : whatsappInstances.map(wp => (
                                    <div key={wp.id} onClick={() => setSelectedWhatsapp(wp.id)} className={`p-4 rounded-xl border cursor-pointer transition flex items-center justify-between ${selectedWhatsapp === wp.id ? 'bg-emerald-600/20 border-emerald-500 text-white' : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-600'}`}>
                                        <span className="font-medium">{wp.name}</span>
                                        {selectedWhatsapp === wp.id && <Check size={18} className="text-emerald-400"/>}
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    {/* PASSO 3: TREINAMENTO */}
                    {step === 3 && (
                        <div className="space-y-4 animate-fade-in-up">
                            <div className="bg-purple-500/10 p-4 rounded-xl border border-purple-500/20 mb-6 flex gap-3">
                                <Brain className="text-purple-400 shrink-0"/>
                                <p className="text-sm text-purple-200">Responda o formulário para treinar a IA.</p>
                            </div>

                            <select value={selectedBase} onChange={e => setSelectedBase(e.target.value)} className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-white outline-none focus:border-purple-500 mb-6">
                                <option value="">Sem treinamento específico (Genérico)</option>
                                {knowledgeBases.map(kb => (
                                    <option key={kb.id} value={kb.id}>{kb.name}</option>
                                ))}
                            </select>

                            {/* Renderização das perguntas (CÓDIGO ANTERIOR) */}
                            {currentBase && currentBase.questions && (
                                <div className="space-y-5 border-t border-slate-800 pt-4">
                                    {currentBase.questions.map((q: any, idx: number) => (
                                        <div key={idx}>
                                            <label className="block text-sm text-purple-300 mb-1 font-medium">{q.text}</label>
                                            {q.type === 'short_text' && <input type="text" className="w-full bg-slate-800 border-slate-700 rounded-lg p-2 text-white" value={answers[idx] || ''} onChange={e => setAnswers({...answers, [idx]: e.target.value})} />}
                                            {q.type === 'long_text' && <textarea rows={3} className="w-full bg-slate-800 border-slate-700 rounded-lg p-2 text-white" value={answers[idx] || ''} onChange={e => setAnswers({...answers, [idx]: e.target.value})}></textarea>}
                                            {q.type === 'select' && <select className="w-full bg-slate-800 border-slate-700 rounded-lg p-2 text-white" value={answers[idx] || ''} onChange={e => setAnswers({...answers, [idx]: e.target.value})}>{q.options?.map((opt:string)=><option key={opt} value={opt}>{opt}</option>)}</select>}
                                            {q.type === 'radio' && <div className="flex flex-col gap-2">{q.options?.map((opt:string)=><label key={opt} className="text-slate-300"><input type="radio" checked={answers[idx]===opt} onChange={()=>setAnswers({...answers, [idx]: opt})} className="mr-2"/>{opt}</label>)}</div>}
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>
                    )}
                </>
            )}
        </div>

        <div className="p-6 border-t border-slate-800 bg-slate-900 rounded-b-2xl flex justify-between">
            {step > 1 ? (<button onClick={() => setStep(step - 1)} className="text-slate-400 hover:text-white px-4 py-2 font-medium">Voltar</button>) : (<div></div>)}
            
            {step < 3 ? (
                <button onClick={() => { if(step === 1 && !name) return alert('Nome obrigatório!'); setStep(step + 1); }} className="bg-blue-600 hover:bg-blue-500 text-white px-6 py-2 rounded-lg font-bold flex items-center gap-2 transition">Próximo <ChevronRight size={18}/></button>
            ) : (
                <button onClick={handleFinish} disabled={isSaving} className="bg-emerald-600 hover:bg-emerald-500 text-white px-8 py-2 rounded-lg font-bold flex items-center gap-2 transition disabled:opacity-70">
                    {isSaving && <Loader2 size={18} className="animate-spin"/>} {agentToEdit ? 'Atualizar Agente' : 'Criar Agente'}
                </button>
            )}
        </div>
      </div>
    </div>
  );
}