<?php

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Factory\AppFactory;
use Illuminate\Database\Capsule\Manager as Capsule;
use Slim\Routing\RouteCollectorProxy;
use App\Middleware\AuthMiddleware;

require __DIR__ . '/../vendor/autoload.php';

// 1. Carrega variáveis
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__ . '/..');
$dotenv->load();

date_default_timezone_set($_ENV['APP_TIMEZONE'] ?? 'America/Sao_Paulo');

// 2. Banco de Dados
$capsule = new Capsule;
$capsule->addConnection([
    'driver'    => $_ENV['DB_DRIVER'] ?? 'mysql',
    'host'      => $_ENV['DB_HOST'] ?? '127.0.0.1',
    'database'  => $_ENV['DB_DATABASE'],
    'username'  => $_ENV['DB_USERNAME'],
    'password'  => $_ENV['DB_PASSWORD'],
    'charset'   => 'utf8', // <--- MUDANÇA CRUCIAL: De 'utf8mb4' para 'utf8'
    'collation' => 'utf8_unicode_ci',
    'prefix'    => '',
    'schema'    => 'public', // Importante para Postgres
    'sslmode'   => 'prefer',
]);
$capsule->setAsGlobal();
$capsule->bootEloquent();

// 3. Inicializa o App
$app = AppFactory::create();

// === PREFLIGHT DO SISTEMA ===
// Rota "boba" só para garantir que OPTIONS exista no roteador
$app->options('/{routes:.+}', function ($request, $response, $args) {
    return $response;
});

// 4. Middlewares do Slim (LIFO - O último adicionado roda primeiro)
$displayErrorDetails = filter_var($_ENV['APP_DEBUG'] ?? false, FILTER_VALIDATE_BOOLEAN);
$app->addErrorMiddleware($displayErrorDetails, true, true);
$app->addBodyParsingMiddleware();
$app->addRoutingMiddleware();

// === 5. CORS BLINDADO (INTERCEPTADOR) ===
// Este middleware roda ANTES de tudo. Se for OPTIONS, ele responde e morre aqui.
$app->add(function ($request, $handler) use ($app) {
    
    // Configuração de Origem
    $origin = $request->getHeaderLine('Origin');
    $allowedOrigins = ['http://localhost:5173', 'http://localhost:3000', $_ENV['FRONTEND_URL'] ?? ''];
    $allowOrigin = in_array($origin, $allowedOrigins) ? $origin : '*';

    // Se for requisição OPTIONS (Preflight), respondemos AGORA sem passar pro Auth
    if ($request->getMethod() === 'OPTIONS') {
        $response = $app->getResponseFactory()->createResponse();
    } else {
        // Se for GET/POST/ETC, deixa seguir o fluxo normal (Auth, Controller...)
        $response = $handler->handle($request);
    }

    // Adiciona os headers de permissão em TODAS as respostas
    return $response
        ->withHeader('Access-Control-Allow-Origin', $allowOrigin)
        ->withHeader('Access-Control-Allow-Headers', 'X-Requested-With, Content-Type, Accept, Origin, Authorization')
        ->withHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS')
        ->withHeader('Access-Control-Allow-Credentials', 'true');
});

// === ROTAS ===
$app->get('/cron/followups', \App\Controllers\AutomationController::class . ':checkFollowUps');

$app->get('/', function (Request $request, Response $response) {
    $payload = json_encode(['status' => 'AgenteUP4 API Online 🚀', 'version' => '2.0 (CORS Fixed)']);
    $response->getBody()->write($payload);
    return $response->withHeader('Content-Type', 'application/json');
});

// Auth (Público)
$app->post('/auth/register', \App\Controllers\AuthController::class . ':register');
$app->post('/auth/login', \App\Controllers\AuthController::class . ':login');

// === ROTAS PROTEGIDAS ===
$app->group('/api', function (RouteCollectorProxy $group) {
    
    // Agenda
    $group->get('/agenda', \App\Controllers\AgendaController::class . ':index');
    $group->post('/agenda', \App\Controllers\AgendaController::class . ':store');
    $group->put('/agenda/{id}', \App\Controllers\AgendaController::class . ':update');
    $group->delete('/agenda/{id}', \App\Controllers\AgendaController::class . ':destroy');

    // CRM
    $group->get('/crm/board', \App\Controllers\CRMController::class . ':index');
    $group->post('/crm/leads', \App\Controllers\CRMController::class . ':store');
    $group->put('/crm/leads/{id}/move', \App\Controllers\CRMController::class . ':move');
    $group->put('/crm/leads/{id}', \App\Controllers\CRMController::class . ':update');
    $group->delete('/crm/leads/{id}', \App\Controllers\CRMController::class . ':destroy');

    // Knowledge Bases
    $group->get('/knowledge-bases', \App\Controllers\KnowledgeBaseController::class . ':index');
    $group->post('/knowledge-bases', \App\Controllers\KnowledgeBaseController::class . ':store');
    $group->put('/knowledge-bases/{id}', \App\Controllers\KnowledgeBaseController::class . ':update');
    $group->delete('/knowledge-bases/{id}', \App\Controllers\KnowledgeBaseController::class . ':destroy');
    
    // WhatsApp
    $group->get('/whatsapp', \App\Controllers\WhatsAppController::class . ':index');
    $group->post('/whatsapp', \App\Controllers\WhatsAppController::class . ':store');
    $group->delete('/whatsapp/{id}', \App\Controllers\WhatsAppController::class . ':destroy');

    // Agentes
    $group->get('/agents', \App\Controllers\AgentController::class . ':index');
    $group->post('/agents', \App\Controllers\AgentController::class . ':store');
    $group->put('/agents/{id}', \App\Controllers\AgentController::class . ':update');
    $group->delete('/agents/{id}', \App\Controllers\AgentController::class . ':destroy');

    // Produtos
    $group->get('/products', \App\Controllers\ProductController::class . ':index');
    $group->post('/products', \App\Controllers\ProductController::class . ':store');
    $group->put('/products/{id}', \App\Controllers\ProductController::class . ':update'); 
    $group->delete('/products/{id}', \App\Controllers\ProductController::class . ':destroy');

    // IA Generativa
    $group->post('/ai/generate', \App\Controllers\AIController::class . ':generate');

})->add(new AuthMiddleware());

$app->run();