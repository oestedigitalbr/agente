<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Lead extends Model {
    protected $table = 'leads';
    
    protected $fillable = [
        'id', 
        'user_id', 
        'name', 
        'phone', 
        'email', 
        'value', 
        'status', 
        'pipeline',       
        'agent_paused',   
        'follow_up_date', 
        'follow_up_notes' 
    ];
    
    public $incrementing = false;
    protected $keyType = 'string';

    protected $casts = [
        'value' => 'float',
        'agent_paused' => 'boolean',
        // 'follow_up_date' => 'datetime' // Opcional, ajuda a formatar direto
    ];

    // --- O CÓDIGO QUE FALTAVA ---
    // Permite que o Lead "veja" seus agendamentos
    public function appointments() {
        return $this->hasMany(Appointment::class, 'lead_id');
    }
}