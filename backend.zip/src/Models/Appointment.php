<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Appointment extends Model {
    
    protected $table = 'appointments';
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'id', 
        'user_id', 
        'lead_id', // <--- O PAI DA CRIANÇA (ADICIONADO)
        'title', 
        'description', 
        'start_time', 
        'end_time', 
        'appointment_date',
        'client_phone', 
        'status'
    ];

    protected $casts = [
        'start_time' => 'datetime',
        'end_time' => 'datetime',
        'appointment_date' => 'datetime'
    ];
}