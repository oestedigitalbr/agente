<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Agent extends Model {
    protected $table = 'agents';
    
    // LISTA DE CAMPOS PERMITIDOS (FILLABLE)
    protected $fillable = [
        'id', 
        'user_id', 
        'whatsapp_instance_id', // <--- TEM QUE TER ISSO
        'knowledge_base_id',    // <--- TEM QUE TER ISSO
        'name', 
        'role', 
        'personality', 
        'is_active'
    ];
    
    public $incrementing = false;
    protected $keyType = 'string';
    
    protected $casts = [
        'is_active' => 'boolean',
    ];

    // Relacionamento com WhatsApp
    public function whatsapp() {
        return $this->belongsTo(WhatsAppInstance::class, 'whatsapp_instance_id');
    }
}