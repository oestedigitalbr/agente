<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Message extends Model {
    protected $table = 'messages';
    protected $fillable = ['id', 'lead_id', 'sender_type', 'content', 'created_at'];
    public $incrementing = false;
    protected $keyType = 'string';
    public $timestamps = false; // Só precisamos do created_at
}