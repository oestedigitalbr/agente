<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Pipeline extends Model {
    protected $table = 'pipelines';
    
    // Adicionado 'type' (bot ou main)
    protected $fillable = ['id', 'user_id', 'name', 'stages', 'type'];
    
    public $incrementing = false;
    protected $keyType = 'string';

    // Garante que o campo stages (JSON) seja lido como array no PHP
    protected $casts = [
        'stages' => 'array',
    ];
}