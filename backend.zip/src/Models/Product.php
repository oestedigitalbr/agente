<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Product extends Model {
    protected $table = 'products';
    protected $fillable = ['id', 'user_id', 'name', 'description', 'sku', 'price', 'image_url', 'is_active'];
    public $incrementing = false;
    protected $keyType = 'string';
}