<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class User extends Model {
    protected $table = 'users';
    protected $fillable = ['id', 'name', 'email', 'password', 'role', 'owner_id', 'plan_config'];
    public $incrementing = false; // Usamos UUID
    protected $keyType = 'string';
}