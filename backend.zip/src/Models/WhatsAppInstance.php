<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class WhatsAppInstance extends Model {
    protected $table = 'whatsapp_instances';
    protected $fillable = ['id', 'user_id', 'name', 'phone_number_id', 'access_token', 'status'];
    public $incrementing = false;
    protected $keyType = 'string';
}