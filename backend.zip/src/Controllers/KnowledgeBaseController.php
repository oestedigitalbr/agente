<?php
namespace App\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Models\KnowledgeBase;
use Ramsey\Uuid\Uuid;

class KnowledgeBaseController {

    public function index(Request $request, Response $response) {
        $userToken = $request->getAttribute('user');
        $bases = KnowledgeBase::where('user_id', $userToken->sub)->get();
        
        $bases = $bases->map(function($base) {
            if (is_string($base->questions)) {
                $base->questions = json_decode($base->questions);
            }
            return $base;
        });

        $response->getBody()->write($bases->toJson());
        return $response->withHeader('Content-Type', 'application/json');
    }

    public function store(Request $request, Response $response) {
        $userToken = $request->getAttribute('user');
        $data = $request->getParsedBody();

        if (empty($data['name'])) {
            $response->getBody()->write(json_encode(['error' => 'Nome é obrigatório']));
            return $response->withStatus(400)->withHeader('Content-Type', 'application/json');
        }

        try {
            $kb = KnowledgeBase::create([
                'id' => Uuid::uuid4()->toString(),
                'user_id' => $userToken->sub,
                'name' => filter_var($data['name'], FILTER_SANITIZE_SPECIAL_CHARS),
                // Eloquent com cast 'array' ou 'json' cuida disso, mas se for text puro:
                'questions' => isset($data['questions']) ? $data['questions'] : [] 
            ]);

            // Se o banco salvou como string, decodifica pra devolver
            if (is_string($kb->questions)) $kb->questions = json_decode($kb->questions);

            $response->getBody()->write($kb->toJson());
            return $response->withStatus(201)->withHeader('Content-Type', 'application/json');

        } catch (\Exception $e) {
            $response->getBody()->write(json_encode(['error' => 'Erro ao salvar', 'details' => $e->getMessage()]));
            return $response->withStatus(500)->withHeader('Content-Type', 'application/json');
        }
    }

    public function update(Request $request, Response $response, array $args) {
        $userToken = $request->getAttribute('user');
        $data = $request->getParsedBody();
        $id = $args['id'];

        try {
            $kb = KnowledgeBase::where('id', $id)->where('user_id', $userToken->sub)->first();
            if (!$kb) return $response->withStatus(404);

            if (isset($data['name'])) $kb->name = filter_var($data['name'], FILTER_SANITIZE_SPECIAL_CHARS);
            if (isset($data['questions'])) $kb->questions = $data['questions'];

            $kb->save();
            if (is_string($kb->questions)) $kb->questions = json_decode($kb->questions);

            $response->getBody()->write($kb->toJson());
            return $response->withHeader('Content-Type', 'application/json');

        } catch (\Exception $e) {
            $response->getBody()->write(json_encode(['error' => $e->getMessage()]));
            return $response->withStatus(500)->withHeader('Content-Type', 'application/json');
        }
    }

    public function destroy(Request $request, Response $response, array $args) {
        $userToken = $request->getAttribute('user');
        $kb = KnowledgeBase::where('id', $args['id'])->where('user_id', $userToken->sub)->first();
        if ($kb) {
            $kb->delete();
            $response->getBody()->write(json_encode(['message' => 'Deletado com sucesso']));
        } else {
            return $response->withStatus(404);
        }
        return $response->withHeader('Content-Type', 'application/json');
    }
}