<?php

namespace App\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Models\Appointment;
use App\Models\Lead; // <--- OBRIGATÓRIO: Importar o Model de Lead
use Illuminate\Database\Capsule\Manager as Capsule;
use Ramsey\Uuid\Uuid;
use DateTime;

class AgendaController
{
    /**
     * 1. LISTAR TUDO (GET /api/agenda)
     * Retorna Agendamentos + Follow-ups unificados
     */
    public function index(Request $request, Response $response, array $args)
    {
        $userToken = $request->getAttribute('user');
        
        // 1. Busca Agendamentos (que não estejam concluídos)
        $appointments = Appointment::where('user_id', $userToken->sub)
                                   ->where('status', '!=', 'completed')
                                   ->orderBy('start_time', 'asc')
                                   ->get()
                                   ->map(function($apt) {
                                       return [
                                           'id' => $apt->id,
                                           'type' => 'appointment', // Etiqueta
                                           'title' => $apt->title,
                                           'description' => $apt->description,
                                           'date' => $apt->start_time,
                                           'lead_id' => $apt->lead_id,
                                           'status' => $apt->status
                                       ];
                                   });

        // 2. Busca Follow-ups (Leads com data marcada)
        $followups = Lead::where('user_id', $userToken->sub)
                         ->whereNotNull('follow_up_date')
                         ->get()
                         ->map(function($lead) {
                             return [
                                 'id' => $lead->id,
                                 'type' => 'follow_up', // Etiqueta diferente
                                 'title' => 'Follow-up: ' . $lead->name,
                                 'description' => $lead->follow_up_notes ?? 'Retorno agendado',
                                 'date' => $lead->follow_up_date,
                                 'lead_id' => $lead->id,
                                 'status' => 'pending'
                             ];
                         });

        // 3. Mistura tudo e ordena por data
        $merged = $appointments->merge($followups)->sortBy('date')->values();

        $response->getBody()->write($merged->toJson());
        return $response->withHeader('Content-Type', 'application/json');
    }

    /**
     * 2. CRIAR (POST /api/agenda)
     */
    public function store(Request $request, Response $response, array $args)
    {
        $data = $request->getParsedBody();
        $userToken = $request->getAttribute('user');

        // Fix de Schema
        try {
            if (!Capsule::schema()->hasColumn('appointments', 'lead_id')) {
                Capsule::schema()->table('appointments', function ($table) {
                    $table->string('lead_id')->nullable()->after('user_id');
                });
            }
            if (!Capsule::schema()->hasColumn('appointments', 'end_time')) {
                Capsule::schema()->table('appointments', function ($table) {
                    $table->dateTime('end_time')->nullable()->after('start_time');
                });
            }
            if (!Capsule::schema()->hasColumn('appointments', 'client_phone')) {
                Capsule::schema()->table('appointments', function ($table) {
                    $table->string('client_phone')->nullable()->after('status');
                });
            }
        } catch (\Exception $e) { }

        if (empty($data['start_time']) || empty($data['title'])) {
            $response->getBody()->write(json_encode(['error' => 'Data e Título são obrigatórios']));
            return $response->withStatus(400)->withHeader('Content-Type', 'application/json');
        }

        try {
            $rawStart = $data['start_time'];
            if (strpos($rawStart, '/') !== false) {
                $dt = DateTime::createFromFormat('d/m/Y H:i', $rawStart);
                if (!$dt) $dt = DateTime::createFromFormat('d/m/Y H:i:s', $rawStart);
                $startTime = $dt ? $dt->format('Y-m-d H:i:s') : date('Y-m-d H:i:s');
            } else {
                $startTime = date('Y-m-d H:i:s', strtotime($rawStart));
            }

            $endTime = !empty($data['end_time']) ? $data['end_time'] : date('Y-m-d H:i:s', strtotime($startTime . ' +1 hour'));

            $appointment = Appointment::create([
                'id' => Uuid::uuid4()->toString(),
                'user_id' => $userToken->sub,
                'lead_id' => !empty($data['lead_id']) ? $data['lead_id'] : null,
                'title' => filter_var($data['title'], FILTER_SANITIZE_SPECIAL_CHARS),
                'description' => !empty($data['description']) ? filter_var($data['description'], FILTER_SANITIZE_SPECIAL_CHARS) : null,
                'appointment_date' => $startTime,
                'start_time' => $startTime,
                'end_time' => $endTime,
                'client_phone' => !empty($data['client_phone']) ? $data['client_phone'] : null,
                'status' => $data['status'] ?? 'scheduled'
            ]);

            $response->getBody()->write($appointment->toJson());
            return $response->withHeader('Content-Type', 'application/json')->withStatus(201);

        } catch (\Exception $e) {
            $response->getBody()->write(json_encode(['error' => 'Erro ao agendar', 'details' => $e->getMessage()]));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(500);
        }
    }

    /**
     * 3. CONCLUIR / ATUALIZAR
     */
    public function update(Request $request, Response $response, array $args)
    {
        $data = $request->getParsedBody();
        $userToken = $request->getAttribute('user');

        try {
            $apt = Appointment::where('id', $args['id'])->where('user_id', $userToken->sub)->first();
            if (!$apt) return $response->withStatus(404);

            $apt->update($data); 

            $response->getBody()->write($apt->toJson());
            return $response->withHeader('Content-Type', 'application/json');

        } catch (\Exception $e) {
            $response->getBody()->write(json_encode(['error' => 'Erro ao atualizar', 'details' => $e->getMessage()]));
            return $response->withStatus(500)->withHeader('Content-Type', 'application/json');
        }
    }

    // 4. DELETAR
    public function destroy(Request $request, Response $response, array $args)
    {
        $userToken = $request->getAttribute('user');
        try {
            $apt = Appointment::where('id', $args['id'])->where('user_id', $userToken->sub)->first();
            if ($apt) {
                $apt->delete();
                $response->getBody()->write(json_encode(['message' => 'Removido']));
            } else {
                return $response->withStatus(404);
            }
            return $response->withHeader('Content-Type', 'application/json');
        } catch (\Exception $e) {
            return $response->withStatus(500);
        }
    }
}