<?php
namespace App\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Models\Lead;
use Ramsey\Uuid\Uuid;

class CRMController {

    /**
     * LISTAR LEADS (Agora trazendo os Agendamentos junto!)
     */
    public function index(Request $request, Response $response) {
        $userToken = $request->getAttribute('user');
        $params = $request->getQueryParams();
        
        // Padrão 'client' se não vier nada
        $pipeline = $params['pipeline'] ?? 'client';

        try {
            // Log para debug
            error_log("Buscando leads para User: {$userToken->sub} | Pipeline: {$pipeline}");

            $query = Lead::where('user_id', $userToken->sub);

            if ($pipeline !== 'all') {
                $query->where('pipeline', $pipeline);
            }

            // --- AQUI ESTÁ A MÁGICA ---
            // Carregamos a relação 'appointments' ordenando pelo mais próximo.
            // Isso garante que o JSON enviado pro frontend tenha a lista de agendamentos.
            $leads = $query->with(['appointments' => function($q) {
                $q->orderBy('start_time', 'asc'); 
            }])
            ->orderBy('created_at', 'desc')
            ->get();
            
            $response->getBody()->write($leads->toJson());
            return $response->withHeader('Content-Type', 'application/json');

        } catch (\Exception $e) {
            error_log("Erro no CRM Index: " . $e->getMessage());
            return $this->jsonResponse($response, [
                'error' => 'Erro ao carregar leads',
                'details' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * CRIAR NOVO LEAD
     */
    public function store(Request $request, Response $response) {
        $userToken = $request->getAttribute('user');
        $data = $request->getParsedBody();

        if (empty($data['name']) || empty($data['phone'])) {
            return $this->jsonResponse($response, ['error' => 'Nome e Telefone são obrigatórios'], 400);
        }

        if (!empty($data['email']) && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            return $this->jsonResponse($response, ['error' => 'Formato de e-mail inválido'], 400);
        }

        $phoneRaw = preg_replace('/[^0-9]/', '', $data['phone']);
        if (strlen($phoneRaw) < 10) {
            return $this->jsonResponse($response, ['error' => 'Telefone inválido (mínimo 10 dígitos)'], 400);
        }

        try {
            // Sanitização moderna
            $cleanName = filter_var($data['name'], FILTER_SANITIZE_SPECIAL_CHARS);

            $lead = Lead::create([
                'id' => Uuid::uuid4()->toString(),
                'user_id' => $userToken->sub,
                'name' => $cleanName,
                'phone' => $data['phone'],
                'email' => $data['email'] ?? '',
                'value' => isset($data['value']) ? floatval($data['value']) : 0,
                'status' => $data['status'] ?? 'new',
                'pipeline' => $data['pipeline'] ?? 'client',
                'agent_paused' => false,
                'follow_up_date' => null,
                'follow_up_notes' => null
            ]);

            $response->getBody()->write($lead->toJson());
            return $response->withStatus(201)->withHeader('Content-Type', 'application/json');

        } catch (\Exception $e) {
            return $this->jsonResponse($response, ['error' => 'Erro ao criar lead', 'details' => $e->getMessage()], 500);
        }
    }

    public function move(Request $request, Response $response, array $args) {
        $userToken = $request->getAttribute('user');
        $data = $request->getParsedBody();
        $id = $args['id'];

        try {
            $lead = Lead::where('id', $id)->where('user_id', $userToken->sub)->first();

            if (!$lead) return $response->withStatus(404);

            if (isset($data['status'])) $lead->status = $data['status'];
            if (isset($data['pipeline'])) $lead->pipeline = $data['pipeline'];
            
            $lead->save();
            $response->getBody()->write($lead->toJson());
            return $response->withHeader('Content-Type', 'application/json');
        } catch (\Exception $e) {
            return $this->jsonResponse($response, ['error' => $e->getMessage()], 500);
        }
    }

    public function update(Request $request, Response $response, array $args) {
        $userToken = $request->getAttribute('user');
        $data = $request->getParsedBody();
        $id = $args['id'];

        try {
            $lead = Lead::where('id', $id)->where('user_id', $userToken->sub)->first();
            if (!$lead) return $response->withStatus(404);

            if (isset($data['name'])) $lead->name = filter_var($data['name'], FILTER_SANITIZE_SPECIAL_CHARS);
            
            if (isset($data['phone'])) $lead->phone = $data['phone'];
            if (isset($data['email'])) {
                 if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
                    return $this->jsonResponse($response, ['error' => 'E-mail inválido'], 400);
                 }
                 $lead->email = $data['email'];
            }
            if (isset($data['value'])) $lead->value = floatval($data['value']);
            
            if (array_key_exists('follow_up_date', $data)) {
                $lead->follow_up_date = !empty($data['follow_up_date']) ? $data['follow_up_date'] : null;
            }
            if (array_key_exists('follow_up_notes', $data)) {
                $lead->follow_up_notes = $data['follow_up_notes'];
            }
            if (isset($data['agent_paused'])) {
                $lead->agent_paused = filter_var($data['agent_paused'], FILTER_VALIDATE_BOOLEAN);
            }

            $lead->save();
            $response->getBody()->write($lead->toJson());
            return $response->withHeader('Content-Type', 'application/json');

        } catch (\Exception $e) {
            return $this->jsonResponse($response, ['error' => 'Erro ao atualizar', 'details' => $e->getMessage()], 500);
        }
    }

    public function destroy(Request $request, Response $response, array $args) {
        $userToken = $request->getAttribute('user');
        try {
            $lead = Lead::where('id', $args['id'])->where('user_id', $userToken->sub)->first();
            if ($lead) {
                $lead->delete();
                return $this->jsonResponse($response, ['message' => 'Lead removido com sucesso']);
            } 
            return $response->withStatus(404);
        } catch (\Exception $e) {
            return $this->jsonResponse($response, ['error' => 'Erro ao deletar', 'details' => $e->getMessage()], 500);
        }
    }

    private function jsonResponse(Response $response, array $data, int $status = 200): Response {
        $response->getBody()->write(json_encode($data));
        return $response->withStatus($status)->withHeader('Content-Type', 'application/json');
    }
}