<?php
namespace App\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Models\WhatsAppInstance;
use Ramsey\Uuid\Uuid;

class WhatsAppController {

    public function index(Request $request, Response $response) {
        $userToken = $request->getAttribute('user');
        $instances = WhatsAppInstance::where('user_id', $userToken->sub)->get();
        $response->getBody()->write($instances->toJson());
        return $response->withHeader('Content-Type', 'application/json');
    }

    public function store(Request $request, Response $response) {
        $userToken = $request->getAttribute('user');
        $data = $request->getParsedBody();

        if (empty($data['name']) || empty($data['phone_number_id']) || empty($data['access_token'])) {
            $response->getBody()->write(json_encode(['error' => 'Todos os campos são obrigatórios']));
            return $response->withStatus(400)->withHeader('Content-Type', 'application/json');
        }

        try {
            $instance = WhatsAppInstance::create([
                'id' => Uuid::uuid4()->toString(),
                'user_id' => $userToken->sub,
                'name' => filter_var($data['name'], FILTER_SANITIZE_SPECIAL_CHARS),
                'phone_number_id' => $data['phone_number_id'],
                'access_token' => $data['access_token'],
                'status' => 'connected'
            ]);

            $response->getBody()->write($instance->toJson());
            return $response->withStatus(201)->withHeader('Content-Type', 'application/json');
        } catch (\Exception $e) {
            $response->getBody()->write(json_encode(['error' => $e->getMessage()]));
            return $response->withStatus(500)->withHeader('Content-Type', 'application/json');
        }
    }
    
    public function destroy(Request $request, Response $response, array $args) {
        $userToken = $request->getAttribute('user');
        try {
            $instance = WhatsAppInstance::where('id', $args['id'])->where('user_id', $userToken->sub)->first();
            if ($instance) {
                $instance->delete();
                $response->getBody()->write(json_encode(['message' => 'Conexão removida']));
            } else {
                return $response->withStatus(404);
            }
            return $response->withHeader('Content-Type', 'application/json');
        } catch (\Exception $e) {
            return $response->withStatus(500);
        }
    }
}