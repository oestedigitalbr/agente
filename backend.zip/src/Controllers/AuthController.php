<?php
namespace App\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Models\User;
use Firebase\JWT\JWT;
use Ramsey\Uuid\Uuid;

class AuthController {
    
    public function register(Request $request, Response $response) {
        $data = $request->getParsedBody();
        
        if (User::where('email', $data['email'])->exists()) {
             $response->getBody()->write(json_encode(['error' => 'Email já cadastrado']));
             return $response->withStatus(400)->withHeader('Content-Type', 'application/json');
        }

        try {
            $user = User::create([
                'id' => Uuid::uuid4()->toString(),
                'name' => filter_var($data['name'], FILTER_SANITIZE_SPECIAL_CHARS),
                'email' => $data['email'],
                'password' => password_hash($data['password'], PASSWORD_BCRYPT),
                'role' => 'owner',
                // Postgres suporta JSON nativo, então isso vai tranquilo
                'plan_config' => ['crm' => true, 'ai' => true] 
            ]);

            $response->getBody()->write(json_encode(['message' => 'Usuário criado!', 'id' => $user->id]));
            return $response->withHeader('Content-Type', 'application/json');
        } catch (\Exception $e) {
            $response->getBody()->write(json_encode(['error' => $e->getMessage()]));
            return $response->withStatus(500)->withHeader('Content-Type', 'application/json');
        }
    }

    public function login(Request $request, Response $response) {
        $data = $request->getParsedBody();
        $user = User::where('email', $data['email'])->first();

        if (!$user || !password_verify($data['password'], $user->password)) {
            $response->getBody()->write(json_encode(['error' => 'Credenciais inválidas']));
            return $response->withStatus(401)->withHeader('Content-Type', 'application/json');
        }

        $payload = [
            'sub' => $user->id,
            'email' => $user->email,
            'role' => $user->role,
            'iat' => time(),
            'exp' => time() + (60 * 60 * 24)
        ];

        $jwt = JWT::encode($payload, $_ENV['JWT_SECRET'], 'HS256');

        $response->getBody()->write(json_encode([
            'token' => $jwt,
            'user' => ['id' => $user->id, 'name' => $user->name, 'role' => $user->role]
        ]));
        
        return $response->withHeader('Content-Type', 'application/json');
    }
}