<?php
namespace App\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Models\Product;
use Ramsey\Uuid\Uuid;

class ProductController {

    public function index(Request $request, Response $response) {
        $userToken = $request->getAttribute('user');
        $products = Product::where('user_id', $userToken->sub)->orderBy('created_at', 'desc')->get();
        $response->getBody()->write($products->toJson());
        return $response->withHeader('Content-Type', 'application/json');
    }

    public function store(Request $request, Response $response) {
        $userToken = $request->getAttribute('user');
        $userId = $userToken->sub;
        $data = $request->getParsedBody();
        $uploadedFiles = $request->getUploadedFiles();
        $uploadedImage = $uploadedFiles['image'] ?? null;
        $imageUrl = null;

        // Upload de Imagem
        if ($uploadedImage && $uploadedImage->getError() === UPLOAD_ERR_OK) {
            $extension = strtolower(pathinfo($uploadedImage->getClientFilename(), PATHINFO_EXTENSION));
            $allowed = ['jpg', 'jpeg', 'png', 'webp'];
            
            if (in_array($extension, $allowed)) {
                $directory = __DIR__ . '/../../public/uploads/' . $userId;
                if (!is_dir($directory)) mkdir($directory, 0755, true);

                $newFilename = Uuid::uuid4()->toString() . '.' . $extension;
                $uploadedImage->moveTo($directory . DIRECTORY_SEPARATOR . $newFilename);
                $imageUrl = '/uploads/' . $userId . '/' . $newFilename;
            }
        }

        // Tratamento de Preço (Evita erro de string no banco numérico)
        $price = isset($data['price']) ? $this->parsePrice($data['price']) : 0.00;

        try {
            $product = Product::create([
                'id' => Uuid::uuid4()->toString(),
                'user_id' => $userId,
                'name' => filter_var($data['name'], FILTER_SANITIZE_SPECIAL_CHARS),
                'description' => !empty($data['description']) ? filter_var($data['description'], FILTER_SANITIZE_SPECIAL_CHARS) : '',
                'sku' => $data['sku'] ?? null,
                'price' => $price,
                'image_url' => $imageUrl
            ]);
            $response->getBody()->write($product->toJson());
            return $response->withStatus(201)->withHeader('Content-Type', 'application/json');
        } catch (\Exception $e) {
            $response->getBody()->write(json_encode(['error' => $e->getMessage()]));
            return $response->withStatus(500)->withHeader('Content-Type', 'application/json');
        }
    }

    public function update(Request $request, Response $response, array $args) {
        $userToken = $request->getAttribute('user');
        $userId = $userToken->sub;
        $productId = $args['id'];
        $data = $request->getParsedBody();
        $uploadedFiles = $request->getUploadedFiles();
        $uploadedImage = $uploadedFiles['image'] ?? null;

        try {
            $product = Product::where('id', $productId)->where('user_id', $userId)->first();
            if (!$product) {
                $response->getBody()->write(json_encode(['error' => 'Produto não encontrado.']));
                return $response->withStatus(404)->withHeader('Content-Type', 'application/json');
            }

            if (isset($data['name'])) $product->name = filter_var($data['name'], FILTER_SANITIZE_SPECIAL_CHARS);
            if (isset($data['description'])) $product->description = filter_var($data['description'], FILTER_SANITIZE_SPECIAL_CHARS);
            if (isset($data['sku'])) $product->sku = $data['sku'];
            if (isset($data['price'])) $product->price = $this->parsePrice($data['price']);

            if ($uploadedImage && $uploadedImage->getError() === UPLOAD_ERR_OK) {
                if ($product->image_url) {
                    $oldFile = __DIR__ . '/../../public' . $product->image_url;
                    if (file_exists($oldFile)) unlink($oldFile);
                }
                $extension = strtolower(pathinfo($uploadedImage->getClientFilename(), PATHINFO_EXTENSION));
                $directory = __DIR__ . '/../../public/uploads/' . $userId;
                if (!is_dir($directory)) mkdir($directory, 0755, true);

                $newFilename = Uuid::uuid4()->toString() . '.' . $extension;
                $uploadedImage->moveTo($directory . DIRECTORY_SEPARATOR . $newFilename);
                $product->image_url = '/uploads/' . $userId . '/' . $newFilename;
            }

            $product->save();
            $response->getBody()->write($product->toJson());
            return $response->withHeader('Content-Type', 'application/json');
        } catch (\Exception $e) {
             $response->getBody()->write(json_encode(['error' => $e->getMessage()]));
             return $response->withStatus(500)->withHeader('Content-Type', 'application/json');
        }
    }

    public function destroy(Request $request, Response $response, array $args) {
        $userToken = $request->getAttribute('user');
        try {
            $product = Product::where('id', $args['id'])->where('user_id', $userToken->sub)->first();
            if (!$product) return $response->withStatus(404);

            if ($product->image_url) {
                $file = __DIR__ . '/../../public' . $product->image_url;
                if (file_exists($file)) unlink($file);
            }
            $product->delete();
            $response->getBody()->write(json_encode(['message' => 'Deletado com sucesso']));
            return $response->withHeader('Content-Type', 'application/json');
        } catch (\Exception $e) {
            return $response->withStatus(500);
        }
    }

    private function parsePrice($priceStr) {
        if (is_numeric($priceStr)) return (float)$priceStr;
        $clean = str_replace(['R$', ' ', '.'], '', $priceStr);
        return (float) str_replace(',', '.', $clean);
    }
}