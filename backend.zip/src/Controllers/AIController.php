<?php
namespace App\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;

class AIController {

    public function generate(Request $request, Response $response) {
        $data = $request->getParsedBody();
        $prompt = $data['prompt'] ?? '';
        $systemInstruction = $data['system_instruction'] ?? "Você é um especialista em Marketing Digital.";

        if (empty($prompt)) {
            $response->getBody()->write(json_encode(['error' => 'O prompt é obrigatório']));
            return $response->withStatus(400)->withHeader('Content-Type', 'application/json');
        }

        $body = [
            'contents' => [[
                'parts' => [['text' => $systemInstruction . "\n\n---\n\n" . "Tarefa do Usuário: " . $prompt]]
            ]]
        ];

        $apiKey = $_ENV['GEMINI_API_KEY'];
        $model = 'gemini-2.0-flash'; 
        $client = new Client();

        try {
            $res = $client->post("https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key={$apiKey}", [
                'json' => $body,
                'headers' => ['Content-Type' => 'application/json'],
                'timeout' => 15
            ]);

            $resultBody = $res->getBody();
            $result = json_decode($resultBody, true);
            $generatedText = $result['candidates'][0]['content']['parts'][0]['text'] ?? 'Sem resposta da IA.';

            $response->getBody()->write(json_encode(['status' => 'success', 'data' => $generatedText]));
            return $response->withHeader('Content-Type', 'application/json');

        } catch (\Exception $e) {
            $response->getBody()->write(json_encode(['error' => 'Erro na IA', 'details' => $e->getMessage()]));
            return $response->withStatus(500)->withHeader('Content-Type', 'application/json');
        }
    }
}