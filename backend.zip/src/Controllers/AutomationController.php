<?php
namespace App\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Models\Lead;

class AutomationController {

    public function checkFollowUps(Request $request, Response $response) {
        $now = date('Y-m-d H:i:s'); // Formato universal DB

        // Boolean no Postgres precisa ser explícito false
        $leads = Lead::whereNotNull('follow_up_date')
                     ->where('follow_up_date', '<=', $now)
                     ->where('agent_paused', false) 
                     ->get();

        $processed = [];

        foreach ($leads as $lead) {
            $instruction = $lead->follow_up_notes ?: "Entre em contato para retomar a conversa.";
            $aiMessage = "Olá $lead->name! $instruction"; // Simulação

            // Limpa para não loopar
            $lead->follow_up_date = null; 
            $lead->follow_up_notes = null; 
            $lead->save();

            $processed[] = ['lead' => $lead->name, 'message' => $aiMessage];
        }

        $response->getBody()->write(json_encode(['status' => 'ok', 'processed' => $processed]));
        return $response->withHeader('Content-Type', 'application/json');
    }
}