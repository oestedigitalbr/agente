<?php
namespace App\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Models\Agent;
use Ramsey\Uuid\Uuid;

class AgentController {

    public function index(Request $request, Response $response) {
        $userToken = $request->getAttribute('user');
        $agents = Agent::with('whatsapp')->where('user_id', $userToken->sub)->get();
        $response->getBody()->write($agents->toJson());
        return $response->withHeader('Content-Type', 'application/json');
    }

    public function store(Request $request, Response $response) {
        $userToken = $request->getAttribute('user');
        $data = $request->getParsedBody();

        if (empty($data['name'])) {
            $response->getBody()->write(json_encode(['error' => 'Nome do agente é obrigatório']));
            return $response->withStatus(400)->withHeader('Content-Type', 'application/json');
        }

        try {
            // BLINDAGEM POSTGRES: String vazia "" deve ser NULL em FKs
            $whatsappId = !empty($data['whatsapp_instance_id']) ? $data['whatsapp_instance_id'] : null;
            $knowledgeBaseId = !empty($data['knowledge_base_id']) ? $data['knowledge_base_id'] : null;

            $agent = Agent::create([
                'id' => Uuid::uuid4()->toString(),
                'user_id' => $userToken->sub,
                'name' => filter_var($data['name'], FILTER_SANITIZE_SPECIAL_CHARS),
                'role' => $data['role'] ?? 'Assistente',
                'personality' => $data['personality'] ?? 'Você é um assistente virtual.',
                'whatsapp_instance_id' => $whatsappId,
                'knowledge_base_id' => $knowledgeBaseId,
                'is_active' => true
            ]);

            $response->getBody()->write($agent->toJson());
            return $response->withStatus(201)->withHeader('Content-Type', 'application/json');

        } catch (\Exception $e) {
            $response->getBody()->write(json_encode([
                'error' => 'Erro interno ao criar agente',
                'details' => $e->getMessage()
            ]));
            return $response->withStatus(500)->withHeader('Content-Type', 'application/json');
        }
    }

    public function update(Request $request, Response $response, array $args) {
        $userToken = $request->getAttribute('user');
        $data = $request->getParsedBody();

        try {
            $agent = Agent::where('id', $args['id'])->where('user_id', $userToken->sub)->first();
            if (!$agent) return $response->withStatus(404);

            if (isset($data['name'])) $agent->name = filter_var($data['name'], FILTER_SANITIZE_SPECIAL_CHARS);
            if (isset($data['role'])) $agent->role = $data['role'];
            if (isset($data['personality'])) $agent->personality = $data['personality'];
            
            // Boolean no Postgres é strict
            if (isset($data['is_active'])) {
                $agent->is_active = filter_var($data['is_active'], FILTER_VALIDATE_BOOLEAN);
            }
            
            if (array_key_exists('whatsapp_instance_id', $data)) {
                $agent->whatsapp_instance_id = !empty($data['whatsapp_instance_id']) ? $data['whatsapp_instance_id'] : null;
            }
            if (array_key_exists('knowledge_base_id', $data)) {
                $agent->knowledge_base_id = !empty($data['knowledge_base_id']) ? $data['knowledge_base_id'] : null;
            }

            $agent->save();
            $response->getBody()->write($agent->toJson());
            return $response->withHeader('Content-Type', 'application/json');
        } catch (\Exception $e) {
             $response->getBody()->write(json_encode(['error' => $e->getMessage()]));
             return $response->withStatus(500)->withHeader('Content-Type', 'application/json');
        }
    }

    public function destroy(Request $request, Response $response, array $args) {
        $userToken = $request->getAttribute('user');
        $agent = Agent::where('id', $args['id'])->where('user_id', $userToken->sub)->first();

        if ($agent) {
            $agent->delete();
            $response->getBody()->write(json_encode(['message' => 'Agente removido']));
        } else {
            return $response->withStatus(404);
        }
        return $response->withHeader('Content-Type', 'application/json');
    }
}